var level4Boss ={

    

preload:function() {

    game.load.image('ground', 'assets/graveyardground.png');
    game.load.image('platform1', 'assets/graveyardplatform1.png');
    //game.load.image('platform2', 'assets/graveyardplatform2.png');
    game.load.image('bg', 'assets/graveyard.png');
    //game.load.spritesheet('player', 'assets/spritesheet.png', 96, 84);
    //game.load.spritesheet('player', 'assets/bunnywork.png', 46, 90, 59);
    
    game.load.spritesheet('player', 'assets/Warrior_Sheet-Effect.png', 69, 44);
    game.load.image('bag','assets/bag.png');
    //game.load.spritesheet('bat', 'assets/bat.png', 46, 30);
    //game.load.spritesheet('mushroom', 'assets/mushroom.png', 32, 32)
    game.load.spritesheet('projectile', 'assets/Projectile 2.png',32,32)
    
    game.load.spritesheet('spirit', 'assets/Vengeful Spirit Sprite Sheet.png', 64, 64)
    
    game.load.spritesheet('bubble', 'assets/Spectral Shield Sprite Sheets.png', 64, 64)
    
    game.load.spritesheet('sword', 'assets/Spectral Sword Sprite Sheet.png', 64, 64)

    
    
    game.load.audio('jump', 'assets/Jump 1.wav');
    game.load.audio('hit', 'assets/Hit damage 1.wav');
    game.load.audio('collect', 'assets/Fruit collect 1.wav');
    game.load.spritesheet('uptime','assets/GuardUp.png',32,32);
        
    var player;
    var platforms;
    var cursors;
    var items;
    var score;
    var scoreText;
    var canDouble=1;
    var enterKey = game.input.keyboard.addKey(Phaser.Keyboard.ENTER);
    var boss
    var mushroomCounter;
    var projectiles;
    var bullet;
    var floor;
    
    var movement;
    var action;
    var actionList;
    
    var playerVuln;
    var enemyVuln;
    
    var playerHealth;
    var timeTilGuard;
},
    
create: function(){
    
    game.world.setBounds(0, 0, 1058, 600);


    score=0;

    this.keyboard = game.input.keyboard;

    background1 = game.add.sprite(0, 0, 'bg')
//    background2 = game.add.sprite(0, 600, 'bg')
//    background3 = game.add.sprite(1058, 0, 'bg')
//    background4 = game.add.sprite(1058, 600, 'bg')
    background1.scale.setTo(4,4)
    platforms = game.add.group();
    platforms.enableBody = true;
    var ground = platforms.create(0, 525, 'ground');
    ground.scale.setTo(2, 2);
    ground.body.immovable = true;
    var ledge = platforms.create(2300,800, 'platform1');
    ledge.body.immovable = true;
    //ledge = platforms.create(400, 320, 'platform2');
    //ledge.body.immovable = true;
    //ledge = platforms.create(10, 100, 'platform1');
    //ledge.body.immovable = true;

    
    items=game.add.group();
    items.enableBody = true;
//    for (var i = 0;i<6 ;i++){
//        var item= items.create(game.world.randomX, game.world.randomY*0.7, 'bag')
//        item.body.gravity.y=300;
//        item.body.bounce.y=0.3 + Math.random()*0.2;
//        item++;
//    }

    player = game.add.sprite(96, 400, 'player');
    camera = game.camera.follow(player, Phaser.Camera.FOLLOW_PLATFORMER);

    
    player.scale.setTo(1.5, 1.5);
    player.health=5;
    playerVuln=true;
    
    game.physics.arcade.enable(player);
    
    player.body.gravity.y = 300;
    
    player.body.setSize(18,33,18,10);
    player.body.collideWorldBounds = true;

    player.animations.add('perish',[26,27,28,29,30,31,32,33,34,35,36],10,false);
    player.animations.add('walk', [6,7,8,9,10,11,12,13], 20, true);
    player.animations.add('hurt',[37],10,false);
    player.animations.add('idle', [0,1,2,3,4,5], 10, true);
    player.animations.add('doublejump',[41, 42, 43, 44, 45],10,true);
    player.animations.add('descending',[46,47,48],10,true);
    player.animations.add('attack',[16,17,18,19,20],20,false);
    
    boss = game.add.sprite(450, 250, 'spirit');
    
    boss.scale.setTo(4.6, 4.6);
    boss.health=20;
    
    game.physics.arcade.enable(boss);
    boss.body.gravity.y = 0;
    boss.body.collideWorldBounds = true;
    
    boss.anchor.setTo(.5,.5);
    boss.scale.x =-4.6;
    boss.animations.add('all', [0, 1, 2, 3, 4, 5, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 48, 49, 50, 51, 52, 53], 10, true);
    
    boss.animations.add('idle', [0, 1, 2, 3, 4, 5], 10, true);
    
    boss.animations.add('attack', [12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23], 10, true);
    
    boss.animations.add('damage', [24, 25, 26, 27, 28, 29], 10, true);
    
    boss.animations.add('death', [36, 37, 38, 39, 40, 41, 42, 43, 44, 45], 10, true);
    
    boss.animations.add('shieldSpawn', [48, 49, 50, 51, 52, 53], 10, true);
    
    
    
    shield = game.add.sprite(450, 250, 'bubble');
    
    shield.scale.setTo(4.6, 4.6);
    shield.health=25;
    
    game.physics.arcade.enable(shield);
    shield.body.gravity.y = 0;
    shield.body.collideWorldBounds = true;
    
    shield.anchor.setTo(.5,.5);
    shield.scale.x =-4.6;
    shield.animations.add('all', [0, 1, 2, 3, 4, 5, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 16, 17, 18, 19, 20, 8, 24, 25, 26, 27, 28, 29, 30, 31, 9, 9, 9, 9, 9, 9, 9, 9], 10, true);
    
    shield.animations.add('spawn', [0, 1, 2, 3, 4, 5], 10, true);
    
    shield.animations.add('idle', [8, 8, 8, 8, 8, 8], 10, true);
    
    shield.animations.add('attack', [8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8], 10, true);
    
    shield.animations.add('damage', [16, 17, 18, 19, 20, 16], 10, true);
    
    shield.animations.add('death', [24, 25, 26, 27, 28, 29, 30, 31, 9, 9], 10, true);
    
    shield.animations.add('noShield', [9, 9, 9, 9, 9], 10, true);
    
    
    boss.body.setSize(31, 41, 15, 18);
    
    shield.body.setSize(52, 52, 6, 7);
    

    cursors = game.input.keyboard.createCursorKeys();
    projectiles=game.add.group();
    projectiles.enableBody=true;
    bullet=projectiles.create(0,0,'projectile');
    bullet.kill();
    bullet.animations.add('fired',[0,1,2,3,4],10,false);
    bullet.animations.add('moving',[5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20],10,true);
    
    
    swords=game.add.group();
    swords.enableBody=true;
    createSword = swords.create(0,0,'sword')
    createSword.kill();
    createSword.animations.add('attack', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 12, 13, 14, 15, 16, 17, 10], 10, false);
    
//    attackBoxes=game.add.group();
//    attackBoxes.enableBody=true;
//    attackBox=projectiles.create(0,0,'48-1');
//    attackBox.kill();
    
    
    fireButton=game.input.keyboard.addKey(Phaser.KeyCode.SPACEBAR);

    scoreText = game.add.text(16, 16, 'score: '+ score, { fontSize: '32px', fill: '#000' });
    cursors = game.input.keyboard.createCursorKeys();
    
    jumpSound = game.add.audio('jump');
    hitSound = game.add.audio('hit');
    collectSound = game.add.audio('collect');

    playerdirection="right";
    enemyVuln=true;
    notAttacking=true;
    isDead=false;
    movement = 1
    cycle = 0
    actionList = ["idle", "idle", "attack"] //"damage1", "damage2", "death"]
    action = 0
    
    startPhase = 350
    
    ticks = 75
    
    appear = 0
    
    playerHealth = game.add.text(player.x, player.y-8, 'HP: <'+player.health +'>' ,{ fontSize: '16px', fill: '#000' });
    
    bossCounter = 0
    shieldCounter = 0
    
    enemyFacing = 0
    
    //boss.anchor.setTo(.5,.5);
    //shield.anchor.setTo(.5,.5);
    
    swordStart = 0
    swordMovement = 0
    
    guardvisual= game.add.sprite(0,0,'uptime');
    guardvisual.animations.add('activation',[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16],20,false);
    guardvisual.kill();

    timeTilGuard=0;
},


update: function(){
    
    
    //boss.animations.play("attack")
    shield.animations.play("idle")
    
    if (boss.frame == 12){
        swordStart = 0
    }
    
    if (boss.frame == 13 && swordStart == 0 && movement == 1){
        phantomSword =swords.create(boss.x-150, boss.y-150,'sword')
        phantomSword.animations.add('attack', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 12, 13, 14, 15, 16, 17, 10], 10, false);
        phantomSword.body.setSize(20, 20, 20, 20);
        phantomSword.scale.setTo(-4.6, 4.6);
        
        
        
        //phantomSword.scale.x =(-4.6)
        phantomSword.lifespan=3000
        phantomSword.animations.play("attack")
        airLineOfSight(player, phantomSword, [400, 300], [1058, 600], [100,100])
        
        swordStart = 1
        
        
    }
    
    if (boss.frame == 13 && swordStart == 0 && movement == 2){
        phantomSword =swords.create(boss.x+150, boss.y-150,'sword')
        phantomSword.animations.add('attack', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 12, 13, 14, 15, 16, 17, 10], 10, false);
        
        phantomSword.body.setSize(20, 20, 20, 20);
        phantomSword.scale.setTo(4.6, 4.6);
        
        //phantomSword.scale.x =(4.6)
        phantomSword.lifespan=3000
        phantomSword.animations.play("attack")
        airLineOfSight(player, phantomSword, [400, 300], [1058, 600], [100,100])
        
        swordStart = 1
        
        swordMovement = enemyDirection(player, boss, swordMovement)
        
//        if (swordMovement == 2){
//            
//            
//        }
        
        
    }
    
    
    bossCounter = groundMovement (boss, bossCounter, 460, 300, 300)
    if (player.body.x < boss.body.x){
        //boss.anchor.setTo(.5,.5);
        boss.scale.x =-4.6;
        
        
        
    }
    else{
        //boss.anchor.setTo(.5,.5);
        
        boss.scale.x =4.6;
        
    }
    
    if (boss.body.x-50 - shield.body.x > 0) {
        //shield.
        shield.body.velocity.x = +300
        
    }
    if (boss.body.x-50 - shield.body.x < 0) {
        //shield.
        shield.body.velocity.x = -300
        
    }

    
    
    movement = enemyDirection(player, boss, movement)
    startPhase++
    if (startPhase == 351){
        whatAnimate(movement, 'idle', boss)
        startPhase = 0
    }
    if (startPhase == ticks){
        action = getRandomInt(actionList.length)
        console.log(actionList[action])
        whatAnimate(movement, actionList[action], boss)
        
        startPhase = 0
        if (actionList[action] == "idle"){
            ticks = 50
        }
        
        if (actionList[action] == "attack"){
            ticks = 50
        }
        
    }
    
    
    if (playerVuln){
        game.physics.arcade.overlap(player,swords,toKill,null,this);
    }
    
    game.physics.arcade.overlap(bullet,boss,weaponInteraction,null,this);
    game.physics.arcade.collide(boss, platforms);
    game.physics.arcade.overlap(player, boss, enemyInteraction, null, this);
    
    game.physics.arcade.overlap(bullet,shield,weaponInteraction,null,this);
    game.physics.arcade.collide(shield, platforms);
    game.physics.arcade.overlap(player, shield, enemyInteraction, null, this);

    game.physics.arcade.collide(player, platforms, platformCollide);

    game.physics.arcade.collide(items,platforms);
    game.physics.arcade.overlap(player,items,getItem,null,this);
    
    
    

    playerHealth.x=player.x-40;
    playerHealth.y=player.y-50;
    playerHealth.text='HP: <'+player.health+'>';
    
    if(!cursors.left.isDown && !cursors.right.isDown){
        player.body.velocity.x=0;
    }

    if (cursors.left.isDown)
    {
        playerdirection= "left";
        player.body.velocity.x = -150;
        player.anchor.setTo(.5,.5);
        player.scale.x =-1.5;
        if(player.body.velocity.y==0){
            player.animations.play('walk');
        }
        
    }

    else if (cursors.right.isDown)
    {
        playerdirection= "right";
     player.body.velocity.x = 150;
     player.anchor.setTo(.5,.5);
     player.scale.x =1.5;
     if(player.body.velocity.y==0){
        player.animations.play('walk');
     }
     
    }


    else if( player.body.velocity.x==0 && player.body.velocity.y==0 && notAttacking && !isDead)
    {
        player.animations.play('idle');
    }
    
    cursors.down.onDown.addOnce(guard,this);
    function guard(){

        if(timeTilGuard==0){
            playerVuln = false;
            player.tint= 0xD3D3D3;   
            game.time.events.add(1000, (function() {
                playerVuln=true;
                player.tint=0xFFFFFF;
            }), this); 
            timeTilGuard=240;    
        
        }
    }
    
    if(timeTilGuard>0){
        if(timeTilGuard==1){
            visual=game.add.sprite(player.x-40,player.y,'uptime');
            visual.scale.setTo(2,1.5)
            visual.animations.add('activation',[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16],60,false)
            visual.animations.play('activation');
            visual.lifespan=700;
        }
        timeTilGuard=timeTilGuard-1;
    }
    
    
    
    
    cursors.up.onDown.add(jumpCheck);
    
    fireButton.onDown.addOnce(shoot,this);
    
    function toKill(){
        //console.log("u were indeed just hit")
        player.damage(1);
        
        playerVuln=false;
        
        //console.log("player invulnerable");
        game.time.events.add(1000, (function() {
            playerVuln = true;
            //console.log("player vulnerable");
        }), this); 
        
           
        if(player.health==0){
            game.state.start('overworldstate');
        }
    }
    
    function shoot() {
        notAttacking=false;
        player.animations.play('attack');
        
            
       
        	var bulletDirection=playerdirection;
            
        	if(bulletDirection=="right"){
            		bullet=projectiles.create(player.x,player.y-25,'projectile');
            		bullet.lifespan=700;
            		bullet.scale.setTo(2,2);
            		
                    
            		bullet.animations.play('moving');
            		bullet.body.velocity.x=375
        	}else if( bulletDirection="left"){
            		bullet=projectiles.create(player.x,player.y-25,'projectile');
            		bullet.lifespan=700;
            		bullet.scale.setTo(-2,2);
            		
            		bullet.animations.play('moving');
            		bullet.body.velocity.x=-375;
            		bullet.scale.x= -2;
        	}

        game.time.events.add(200, (function() {    
            notAttacking=true;
        }), this); 

        
    }

    
    function jumpCheck() {
        if((jumpCount < 1) && (player.body.touching.down)){
            jump();
           jumpHeight=0.66;
            jumpSound.play();
            
        }
        if((jumpCount < 2) && (!player.body.touching.down)){
            jump();
            jumpSound.play()
  
        }

    }

    function jump(){
       
        jumpCount ++;
        player.body.velocity.y = -350*jumpHeight;
        player.animations.play('doublejump');
        jumpSound.play();
    }

    
    
    if (player.body.velocity.y >0){
        player.animations.play('descending');
    }
    var enterKey = game.input.keyboard.addKey(Phaser.Keyboard.ENTER);
    var attacking
        
    function platformCollide(){
    
        if(player.body.touching.down){
            jumpCount = 0;
            jumpHeight=1;
        }
        
    }
    
    
    function enemyInteraction (player, enemy) {
        
        if(player.body.touching.down && enemy.body.touching.up ){
            if(enemyVuln){
                if(enemy.health==1){
                    score += 1;
                    scoreText.text = "Score: " + score;
                }
                //console.log("detect goomba");
                enemy.damage(1);
                hitSound.play();
                enemyVuln=false;
                game.time.events.add(4000, (function() {
                    enemyVuln = true;
                  //  console.log("enemy vulnerable");
                }), this); 
            }
            //enemy.body.velocity.setTo(-200,400);
            jumpCount=1;
            jumpHeight=0.33;
            jump();
            jumpCount=1;
            jumpHeight=0.66;
            
            
        }else {if(playerVuln){
           // console.log("detect damage");
           if(player.health==1){
            
            isDead=true;
            player.animations.play('perish'); 
            game.time.events.add(2000,function(){
                console.log('trying to animate')
                
                game.time.events.add(1000,function(){
                    console.log('murder committed')
                    game.state.start('overworldstate');});
                
            });
            
           }
           
           player.damage(1);
           playerVuln=false;
           //console.log("player invulnerable");
           player.animations.play('hurt');
           game.time.events.add(700, (function() {
                playerVuln = true;
                //console.log("player vulnerable");
           }), this); 
           
           
           
        }
    }
    }


    function weaponInteraction(bullet,enemy){
        if(enemy.health==1){
            score += 1;
            scoreText.text = "Score: " + score;
        }
        enemy.damage(1);
        bullet.kill();
        
    }
    function enemyDirection(player, enemy, movement){
        playersXCords = player.body.x
        enemyXCords = enemy.body.x
        //xDistanceAbs = Math.abs(enemyXCords - playersXCords)
        
        if (enemyXCords - playersXCords >= 0){
            return (1)
        }
        else {
            return (2)
        }
    }
    
    
    
    
    function airLineOfSight (player, enemy, enemyCords, enemySight, enemySpeed){
        playersXCords = player.body.x
        playersYCords = player.body.y
        enemyXCords = enemy.body.x
        enemyYCords = enemy.body.y
        xDistanceAbs = Math.abs(enemyXCords - playersXCords)
        yDistanceAbs = Math.abs(enemyYCords - playersYCords)
        xDistance = enemyXCords - playersXCords
        yDistance = enemyYCords - playersYCords
        if (xDistanceAbs <= enemySight[0] && yDistanceAbs <= enemySight[0]){
            
            
            if (xDistance <= 0 && yDistance <= 0){
                //enemy.anchor.setTo(.5,.5);
                //enemy.scale.x =-4.6;
                enemy.body.velocity.x = +enemySpeed[0]
                enemy.body.velocity.y = +enemySpeed[1]
            }
            else if (xDistance > 0 && yDistance > 0){
                //enemy.anchor.setTo(.5,.5);
                //enemy.scale.x =4.6;
                enemy.body.velocity.x = -enemySpeed[0]
                enemy.body.velocity.y = -enemySpeed[1]
            }
            else if (xDistance <= 0 && yDistance > 0){
                //enemy.anchor.setTo(.5,.5);
                //enemy.scale.x =-4.6;
                enemy.body.velocity.x = +enemySpeed[0]
                enemy.body.velocity.y = -enemySpeed[1]
            }
            else if (xDistance > 0 && yDistance <= 0){
                enemy.body.velocity.x = -enemySpeed[0]
                enemy.body.velocity.y = +enemySpeed[1]
            }
        }
        else if (enemyXCords == enemyCords[0] && enemyYCords == enemyCords[1]){
            //enemy.anchor.setTo(.5,.5);
            //enemy.scale.x =4.6;
            enemy.body.velocity.x = 0
            enemy.body.velocity.y = 0    
        }
        else {
            if (enemyXCords >= enemyCords[0]){
                enemy.body.velocity.x = -enemySpeed[0]
            }
            else {
                enemy.body.velocity.x = +enemySpeed[0]
            }
            if (enemyYCords >= enemyCords[1]){
                enemy.body.velocity.y = -enemySpeed[1]
            }
            else {
                enemy.body.velocity.y = +enemySpeed[1]
            }
            
        }
                 
        
        
    }
    


    function getItem(player, items){
        items.kill();
        score += 1;
        scoreText.text = "Score: " + score;
        console.log(score)
        collectSound.play();
    }
    function groundMovement (enemy, counter, xCords, xDist, speed){
    
        enemyPosition = enemy.body.x
        farLeft = xCords - xDist
        farRight = xCords + xDist
        //console.log (enemyPosition)
        if (counter == 0) {
            enemy.body.velocity.x = -speed
            if (enemyPosition <= farLeft) {
            
                counter += 1
            }
        
        }
        else if (counter == 1) {
            enemy.body.velocity.x = +speed
            if (enemyPosition >= farRight){
            
                counter -= 1
            }
        
        }
        return counter

    }
    
    function Phase(startPhase){
        console.log(startPhase)
    }
    
    function getRandomInt(max) {
        return Math.floor(Math.random() * max);
    }
    
    function hitboxCreate(){
        console.log("create later")
    }
    
    
    function whatAnimate (movement, action, enemy){
        
        
    
    
        if (movement == 1){
            
            boss.scale.x =-4.6;
            if (action == "idle" || action == "attack" || action == "damage" || action == "death"){
            
                enemy.animations.play(action)
            }
            
            
                
            
            
        }
        if (movement == 2){
            
            boss.scale.x =4.6;
            if (action == "idle" || action == "attack" || action == "damage" || action == "death"){
            
                enemy.animations.play(action)
            }
            
            
        }
        
//        cycle ++
//        if (cycle > 9){
//            cycle = 0
//        }
//        
//        startPhase ++
        
        
        
    }
    
    if (score == 2) {
        game.state.start('winState');
    }
    
}
}