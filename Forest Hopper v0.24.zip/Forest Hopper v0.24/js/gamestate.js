

var gamestate={

    

preload:function() {

    game.load.image('ground', 'assets/floor.png');
    game.load.image('platform', 'assets/platformlevel1.png');
    game.load.image('platformbg', 'assets/platformlevel1bg.png');
    game.load.image('bg1', 'assets/level1.png');
    //game.load.spritesheet('player', 'assets/spritesheet.png', 96, 84);
    game.load.spritesheet('player', 'assets/Warrior_Sheet-effect.png', 69, 44);
    game.load.image('crystal','assets/crystal.png');
    game.load.spritesheet('bat', 'assets/bat.png', 46, 30);
    game.load.spritesheet('mushroom', 'assets/mushroom.png', 32, 32)
    game.load.spritesheet('projectile', 'assets/Projectile 2.png',32,32)
    game.load.audio('jump', 'assets/Jump 1.wav');
    game.load.audio('hit', 'assets/Hit damage 1.wav');
    game.load.audio('collect', 'assets/Fruit collect 1.wav');
    
    game.load.spritesheet('uptime','assets/GuardUp.png',32,32);
        
    var fireButton; 
    var bullet;
    var playerdirection;
	var projectiles;
    var isDead; 
    var player;
    var platforms;
    var cursors;
    var items;
    var score;
    var scoreText;
    var canDouble=1;
    var enterKey = game.input.keyboard.addKey(Phaser.Keyboard.ENTER);
    var batEnemy;
    var mushroomEnemy
    var mushroomCounter;
    var playerVuln;
    var enemyVuln;
    var notAttacking;
    var playerHealth;
    var lastX;
    var lastY;
    var timeTilGuard;

},
 
create: function(){
    
    // set world to however big you want it to be
    //Camera code line 86
    //game.world.setBounds(0, 0, 4232, 2400);

    score=0;

    this.keyboard = game.input.keyboard;

    game.add.sprite(0, 0, 'bg1');
    
    game.add.sprite(800,150, 'platformbg');
    game.add.sprite(400,320, 'platformbg');
    game.add.sprite(10,100, 'platformbg');
    platforms = game.add.group();
    platforms.enableBody = true;
    
    
    var ground = platforms.create(0, 536, 'ground');
    ground.scale.setTo(2, 2);
    ground.body.immovable = true;
    
    
    var ground2 = platforms.create(0, 2336, 'ground');
    ground2.scale.setTo(5, 2);
    ground2.body.immovable = true;
    
    
    var ledge = platforms.create(800, 150, 'platform');
    ledge.body.immovable = true;
    ledge = platforms.create(400, 320, 'platform');
    ledge.body.immovable = true;
    ledge = platforms.create(10, 100, 'platform');
    ledge.body.immovable = true;

    
    items=game.add.group();
    items.enableBody = true;
    for (var i = 0;i<10 ;i++){
        var item= items.create(game.world.randomX, game.world.randomY*0.7,'crystal')
        item.body.gravity.y=300;
        item.body.bounce.y=0.3 + Math.random()*0.2;
        item++;
    }

    player = game.add.sprite(96, 473, 'player');
    camera = game.camera.follow(player, Phaser.Camera.FOLLOW_PLATFORMER);
    player.scale.setTo(1.5, 1.5);
    player.health=5;
    playerVuln=true;
    
    game.physics.arcade.enable(player);
    
    player.body.gravity.y = 300;
    player.body.setSize(18,33,18,10);
    player.body.collideWorldBounds = true;

    player.animations.add('perish',[26,27,28,29,30,31,32,33,34,35,36],10,false);
    player.animations.add('walk', [6,7,8,9,10,11,12,13], 20, true);
    player.animations.add('hurt',[37],10,false);
    player.animations.add('idle', [0,1,2,3,4,5], 10, true);
    player.animations.add('doublejump',[41, 42, 43, 44, 45],10,true);
    player.animations.add('descending',[46,47,48],10,true);
    player.animations.add('attack',[16,17,18,19,20],20,false);

    batEnemy = game.add.sprite(400, 300, 'bat');
    batEnemy.health=3;
    game.physics.arcade.enable(batEnemy);
    batEnemy.body.collideWorldBounds = true;
    batEnemy.animations.add('flying', [0, 1, 2, 3, 4, 5, 6], 10, true);
    
    mushroomCounter = 0
    mushroomEnemy = game.add.sprite(600, 500, 'mushroom')
    mushroomEnemy.health=2;
    game.physics.arcade.enable(mushroomEnemy);
    mushroomEnemy.body.gravity.y = 300;
    mushroomEnemy.body.collideWorldBounds = true;
    mushroomEnemy.animations.add('left', [19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34], 20, true);
    mushroomEnemy.animations.add('right', [19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34], 20, true);
    mushroomEnemy.animations.add('idle', [5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 18], 20, true);


    cursors = game.input.keyboard.createCursorKeys();

    projectiles=game.add.group();
    projectiles.enableBody=true;
    bullet=projectiles.create(0,0,'projectile');
   	bullet.kill();
   	
   	bullet.animations.add('moving',[0,1,2,3,4,5,6,7],10,true);
    fireButton=game.input.keyboard.addKey(Phaser.KeyCode.SPACEBAR);

    scoreText = game.add.text(16, 16, 'score: '+ score, { fontSize: '32px', fill: '#000' });
    cursors = game.input.keyboard.createCursorKeys();
    
    jumpSound = game.add.audio('jump');
    hitSound = game.add.audio('hit');
    collectSound = game.add.audio('collect');
    
    playerdirection="right";
    enemyVuln=true;
    notAttacking=true;
    isDead=false;
    
    playerHealth = game.add.text(player.x, player.y-8, 'HP: <'+player.health +'>' ,{ fontSize: '16px', fill: '#000' });
    
    guardvisual= game.add.sprite(0,0,'uptime');
    guardvisual.animations.add('activation',[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16],20,false);
    guardvisual.kill();

    timeTilGuard=0;
},


update: function(){

    
    batEnemy.animations.play('flying');
    mushroomEnemy.animations.play('idle');   
    
    
    airLineOfSight(player, batEnemy, [400, 300], [150, 100], [50,50]);

    game.physics.arcade.collide(player, platforms,platformCollide);
    game.physics.arcade.collide(batEnemy, platforms);
    game.physics.arcade.collide(items,platforms);
    game.physics.arcade.overlap(player,items,getItem,null,this);
    game.physics.arcade.overlap(player, batEnemy, enemyInteraction, null, this);
    game.physics.arcade.overlap(bullet,batEnemy,weaponInteraction,null,this);
    game.physics.arcade.overlap(bullet,mushroomEnemy,weaponInteraction,null,this);
    game.physics.arcade.collide(mushroomEnemy, platforms);
    game.physics.arcade.overlap(player, mushroomEnemy, enemyInteraction, null, this);
    
    game.physics.arcade.collide(player, platforms,platformCollide);
    game.physics.arcade.collide(batEnemy, platforms);
    game.physics.arcade.collide(items,platforms);
    game.physics.arcade.overlap(player,items,getItem,null,this);
    game.physics.arcade.collide(player, batEnemy, enemyInteraction, null, this);
    game.physics.arcade.collide(bullet,batEnemy,weaponInteraction,null,this);
    game.physics.arcade.collide(bullet,mushroomEnemy,weaponInteraction,null,this);
    game.physics.arcade.collide(mushroomEnemy, platforms);
    game.physics.arcade.collide(player, mushroomEnemy, enemyInteraction, null, this);

    //enemy, counter, xCords, xDist, yDist, speed
    mushroomCounter = groundMovement(mushroomEnemy, mushroomCounter, 600, 100, 75);
    
    playerHealth.x=player.x-40;
    playerHealth.y=player.y-50;
    playerHealth.text='HP: <'+player.health+'>';
    

    if(!cursors.left.isDown && !cursors.right.isDown){
        player.body.velocity.x=0;
    }

    if (cursors.left.isDown)
    {
        playerdirection= "left";
        player.body.velocity.x = -150;
        player.anchor.setTo(.5,.5);
        player.scale.x =-1.5;
        if(player.body.velocity.y==0){
            player.animations.play('walk');
        }
        
    }

    else if (cursors.right.isDown)
    {
        playerdirection= "right";
     player.body.velocity.x = 150;
     player.anchor.setTo(.5,.5);
     player.scale.x =1.5;
     if(player.body.velocity.y==0){
        player.animations.play('walk');
     }
     
    }


    else if( player.body.velocity.x==0 && player.body.velocity.y==0 && notAttacking && !isDead)
    {
        player.animations.play('idle');
    }
    
    cursors.down.onDown.addOnce(guard,this);
    function guard(){

        if(timeTilGuard==0){
            playerVuln = false;
            player.tint= 0xD3D3D3;   
            game.time.events.add(1000, (function() {
                playerVuln=true;
                player.tint=0xFFFFFF;
            }), this); 
            timeTilGuard=240;    
        
        }
    }
    
    if(timeTilGuard>0){
        if(timeTilGuard==1){
            visual=game.add.sprite(player.x-40,player.y,'uptime');
            visual.scale.setTo(2,1.5)
            visual.animations.add('activation',[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16],60,false)
            visual.animations.play('activation');
            visual.lifespan=700;
        }
        timeTilGuard=timeTilGuard-1;
    }
    
    
    
    cursors.up.onDown.add(jumpCheck);

    
    fireButton.onDown.addOnce(shoot,this);


    function shoot() {
        notAttacking=false;
        player.animations.play('attack');
        	var bulletDirection=playerdirection;
            
        	if(bulletDirection=="right"){
            		bullet=projectiles.create(player.x,player.y-25,'projectile');
            		bullet.lifespan=700;
            		bullet.scale.setTo(2,2);
            		
                    
            		bullet.animations.play('moving');
            		bullet.body.velocity.x=375
        	}else if( bulletDirection="left"){
            		bullet=projectiles.create(player.x,player.y-25,'projectile');
            		bullet.lifespan=700;
            		bullet.scale.setTo(-2,2);
            		
            		bullet.animations.play('moving');
            		bullet.body.velocity.x=-375;
            		bullet.scale.x= -2;
        	}

        game.time.events.add(200, (function() {    
            notAttacking=true;
        }), this); 

        
    	}




    
    function jumpCheck() {
        if((jumpCount < 1) && (player.body.touching.down)){
            jump();
           jumpHeight=0.66;
            jumpSound.play();
            
        }
        if((jumpCount < 2) && (!player.body.touching.down)){
            jump();
            jumpSound.play()
  
        }

    }
    




    function jump(){
       
        jumpCount ++;
        player.body.velocity.y = -350*jumpHeight;
        player.animations.play('doublejump');
        jumpSound.play();
    }
        
    function platformCollide(){
        if(player.body.touching.down){
            jumpCount = 0;
            jumpHeight=1;
        }
        
    }
    function enemyInteraction (player, enemy) {
        
        if(player.body.touching.down && enemy.body.touching.up ){
            if(enemyVuln){
                if(enemy.health==1){
                    score += 1;
                    scoreText.text = "Score: " + score;
                }
                //console.log("detect goomba");
                enemy.damage(1);
                hitSound.play();
                enemyVuln=false;
                game.time.events.add(400, (function() {
                    enemyVuln = true;
                  //  console.log("enemy vulnerable");
                }), this); 
            }
            enemy.body.velocity.setTo(-200,400);
            jumpCount=1;
            jumpHeight=0.33;
            jump();
            jumpCount=1;
            jumpHeight=0.66;
            
            
        }else {if(playerVuln){
           // console.log("detect damage");
           if(player.health==1){
            
            isDead=true;
            player.animations.play('perish'); 
            game.time.events.add(2000,function(){
                console.log('trying to animate')
                
                game.time.events.add(1000,function(){
                    console.log('murder committed')
                    game.state.start('deathState');});
                
            });
            
           }
           
           player.damage(1);
           playerVuln=false;
           //console.log("player invulnerable");
           player.animations.play('hurt');
           game.time.events.add(700, (function() {
                playerVuln = true;
                //console.log("player vulnerable");
           }), this); 
           
           
           
        }
    }
    }


    function weaponInteraction(bullet,enemy){
        if(enemy.health==1){
            score += 1;
            scoreText.text = "Score: " + score;
        }
        enemy.damage(1);
        bullet.kill();
        
    }

    function airLineOfSight (player, enemy, enemyCords, enemySight, enemySpeed){
        playersXCords = player.body.x
        playersYCords = player.body.y
        enemyXCords = enemy.body.x
        enemyYCords = enemy.body.y
        xDistanceAbs = Math.abs(enemyXCords - playersXCords)
        yDistanceAbs = Math.abs(enemyYCords - playersYCords)
        xDistance = enemyXCords - playersXCords
        yDistance = enemyYCords - playersYCords
        if (xDistanceAbs <= enemySight[0] && yDistanceAbs <= enemySight[0]){
            
            
            if (xDistance <= 0 && yDistance <= 0){
                enemy.anchor.setTo(.5,.5);
                enemy.scale.x =-1;
                enemy.body.velocity.x = +enemySpeed[0]
                enemy.body.velocity.y = +enemySpeed[1]
            }
            else if (xDistance > 0 && yDistance > 0){
                enemy.anchor.setTo(.5,.5);
                enemy.scale.x =1;
                enemy.body.velocity.x = -enemySpeed[0]
                enemy.body.velocity.y = -enemySpeed[1]
            }
            else if (xDistance <= 0 && yDistance > 0){
                enemy.anchor.setTo(.5,.5);
                enemy.scale.x =-1;
                enemy.body.velocity.x = +enemySpeed[0]
                enemy.body.velocity.y = -enemySpeed[1]
            }
            else if (xDistance > 0 && yDistance <= 0){
                enemy.body.velocity.x = -enemySpeed[0]
                enemy.body.velocity.y = +enemySpeed[1]
            }
        }
        else if (enemyXCords == enemyCords[0] && enemyYCords == enemyCords[1]){
            enemy.anchor.setTo(.5,.5);
            enemy.scale.x =1;
            enemy.body.velocity.x = 0
            enemy.body.velocity.y = 0    
        }
        else {
            if (enemyXCords >= enemyCords[0]){
                enemy.body.velocity.x = -enemySpeed[0]
            }
            else {
                enemy.body.velocity.x = +enemySpeed[0]
            }
            if (enemyYCords >= enemyCords[1]){
                enemy.body.velocity.y = -enemySpeed[1]
            }
            else {
                enemy.body.velocity.y = +enemySpeed[1]
            }
            
        }
                 
        
        
    }
    


    function getItem(player, items){
        items.kill();
        score += 1;
        scoreText.text = "Score: " + score;
        
        collectSound.play();
    }
    function groundMovement (enemy, counter, xCords, xDist, speed){
    
        enemyPosition = enemy.body.x
        farLeft = xCords - xDist
        farRight = xCords + xDist
        
        if (counter == 0) {
            enemy.body.velocity.x = -speed
            if (enemyPosition <= farLeft) {
            
                counter += 1
            }
        
        }
        else if (counter == 1) {
            enemy.body.velocity.x = +speed
            if (enemyPosition >= farRight){
            
                counter -= 1
            }
        
        }
        return counter

    }
    
    if (score >= 10) {


        game.state.start('getReadyState1');
    }
    
}
}
