var level1Boss ={

    

preload:function() {

    game.load.image('ground', 'assets/graveyardground.png');
    game.load.image('platform1', 'assets/graveyardplatform1.png');
    //game.load.image('platform2', 'assets/graveyardplatform2.png');
    game.load.image('bg', 'assets/graveyard.png');
    //game.load.spritesheet('player', 'assets/spritesheet.png', 96, 84);
    game.load.spritesheet('player', 'assets/Warrior_Sheet-Effect.png', 69, 44);
    game.load.image('bag','assets/bag.png');
    
    
    
    
    game.load.image('130','assets/minotaurHitboxes/130.png');
    game.load.image('131-1','assets/minotaurHitboxes/131(1).png');
    game.load.image('131-2','assets/minotaurHitboxes/131(2).png');
    game.load.image('132-1','assets/minotaurHitboxes/132(1).png');
    game.load.image('132-2','assets/minotaurHitboxes/132(2).png');
    game.load.image('133','assets/minotaurHitboxes/133.png');
    game.load.image('134','assets/minotaurHitboxes/134.png');
    game.load.image('135','assets/minotaurHitboxes/135.png');
    game.load.image('136','assets/minotaurHitboxes/136.png');
    
    
    game.load.image('140','assets/minotaurHitboxes/140.png');
    game.load.image('141','assets/minotaurHitboxes/141.png');
    game.load.image('142','assets/minotaurHitboxes/142.png');
    game.load.image('143','assets/minotaurHitboxes/143.png');
    game.load.image('144','assets/minotaurHitboxes/144.png');
    game.load.image('150','assets/minotaurHitboxes/150.png');
    game.load.image('151','assets/minotaurHitboxes/151.png');
    game.load.image('152','assets/minotaurHitboxes/152.png');
    game.load.image('153','assets/minotaurHitboxes/153.png');
    game.load.image('154','assets/minotaurHitboxes/154.png');
    game.load.image('155','assets/minotaurHitboxes/155.png');
    game.load.image('160','assets/minotaurHitboxes/160.png');
    game.load.image('161','assets/minotaurHitboxes/161.png');
    game.load.image('162','assets/minotaurHitboxes/162.png');
    game.load.image('163','assets/minotaurHitboxes/163.png');
    game.load.image('164','assets/minotaurHitboxes/164.png');
    game.load.image('165','assets/minotaurHitboxes/165.png');
    game.load.image('166','assets/minotaurHitboxes/166.png');
    game.load.image('167','assets/minotaurHitboxes/167.png');
    game.load.image('168','assets/minotaurHitboxes/168.png');
    
    
    
    //game.load.spritesheet('bat', 'assets/bat.png', 46, 30);
    //game.load.spritesheet('mushroom', 'assets/mushroom.png', 32, 32)
    game.load.spritesheet('projectile', 'assets/Projectile 2.png',32,32)
    
    game.load.spritesheet('minotaur', 'assets/Minotaur - Sprite Sheet.png', 96, 96)
    
    game.load.audio('jump', 'assets/Jump 1.wav');
    game.load.audio('hit', 'assets/Hit damage 1.wav');
    game.load.audio('collect', 'assets/Fruit collect 1.wav');
    
    game.load.spritesheet('uptime','assets/GuardUp.png',32,32);
        
    var player;
    var platforms;
    var cursors;
    var items;
    var score;
    var scoreText;
    var canDouble=1;
    var enterKey = game.input.keyboard.addKey(Phaser.Keyboard.ENTER);
    //var batEnemy;
    //var mushroomEnemy
    var boss
    var mushroomCounter;
    var projectiles;
    var bullet;
    var floor;
    var isDead; 
    var movement;
    var action;
    var actionList;
    var notAttacking;
    var playerVuln;
    var enemyVuln;
    
    var playerHealth;
    var isAttacking;
    var timeTilGuard;
    
},
    
create: function(){
    
    game.world.setBounds(0, 0, 1058, 600);


    score=0;

    this.keyboard = game.input.keyboard;

    background1 = game.add.sprite(0, 0, 'bg')
    background1.scale.setTo(4,4)
    platforms = game.add.group();
    platforms.enableBody = true;
    var ground = platforms.create(0, 525, 'ground');
    ground.scale.setTo(2, 2);
    ground.body.immovable = true;
    var ledge = platforms.create(2300,800, 'platform1');
    ledge.body.immovable = true;
    //ledge = platforms.create(400, 320, 'platform2');
    //ledge.body.immovable = true;
    //ledge = platforms.create(10, 100, 'platform1');
    //ledge.body.immovable = true;

    
    items=game.add.group();
    items.enableBody = true;
//    for (var i = 0;i<6 ;i++){
//        var item= items.create(game.world.randomX, game.world.randomY*0.7, 'bag')
//        item.body.gravity.y=300;
//        item.body.bounce.y=0.3 + Math.random()*0.2;
//        item++;
//    }

    player = game.add.sprite(96, 400, 'player');
    camera = game.camera.follow(player, Phaser.Camera.FOLLOW_PLATFORMER);

    
    player.scale.setTo(1.5, 1.5);
    player.health=5;
    playerVuln=true;
    
    game.physics.arcade.enable(player);
    
    player.body.gravity.y = 300;
    
    player.body.setSize(18,33,18,10);
    player.body.collideWorldBounds = true;

    player.animations.add('perish',[26,27,28,29,30,31,32,33,34,35,36],10,false);
    player.animations.add('walk', [6,7,8,9,10,11,12,13], 20, true);
    player.animations.add('hurt',[37],10,false);
    player.animations.add('idle', [0,1,2,3,4,5], 10, true);
    player.animations.add('doublejump',[41, 42, 43, 44, 45],10,true);
    player.animations.add('descending',[46,47,48],10,true);
    player.animations.add('attack',[16,17,18,19,20],20,false);
    
    boss = game.add.sprite(400, 200, 'minotaur');
    boss.scale.setTo(4.6, 4.6);
    boss.health=20;
    game.physics.arcade.enable(boss);
    boss.body.gravity.y = 300;
    boss.body.collideWorldBounds = true;
    boss.animations.add('all', [0, 1, 2, 3, 4, 10, 11, 12, 13, 14, 15, 16, 17, 20, 21, 22, 23, 24, 30, 31, 32, 33, 34, 35, 36, 37, 38, 40, 41, 42, 43, 44, 50, 51, 52, 53, 54, 55, 60, 61, 62, 63, 64, 65, 66, 67, 68, 70, 71, 72, 80, 81, 82, 90, 91, 92, 93, 94, 95, 100, 101, 102, 103, 104, 110, 111, 112, 113, 114, 115, 116, 117, 120, 121, 122, 123, 124, 130, 131, 132, 133, 134, 135, 136, 137, 138, 140, 141, 142, 143, 144, 150, 151, 152, 153, 154, 155, 160, 161, 162, 163, 164, 165, 166, 167, 168, 170, 171, 172, 180, 181, 182, 190, 191, 192, 193, 194, 195], 10, true);
    
    boss.animations.add('idleRight', [0, 1, 2, 3, 4], 7, true);
    
    boss.animations.add('moveRight', [10, 11, 12, 13, 14, 15, 16, 17], 10, true);
    
    boss.animations.add('tauntRight', [20, 21, 22, 23, 24], 5, true);
    
    boss.animations.add('attack1Right', [30, 31, 32, 33, 34, 35, 36, 37, 38], 10, true);
    
    boss.animations.add('attack2Right', [40, 41, 42, 43, 44], 10, true);
    
    boss.animations.add('attack3Right', [50, 51, 52, 53, 54, 55], 10, true);
    
    boss.animations.add('attack4Right', [60, 61, 62, 63, 64, 65, 66, 67, 68], 10, true);
    
    boss.animations.add('damage1Right', [70, 71, 72], 10, true);
    
    boss.animations.add('damage2Right', [80, 81, 82], 10, true);
    
    boss.animations.add('deathRight', [90, 91, 92, 93, 94, 95], 10, true);
    
    boss.animations.add('idleLeft', [100, 101, 102, 103, 104], 7, true);
    
    boss.animations.add('moveLeft', [110, 111, 112, 113, 114, 115, 116, 117], 10, true);
    
    boss.animations.add('tauntLeft', [120, 121, 122, 123, 124], 5, true);
    
    boss.animations.add('attack1Left', [130, 131, 132, 133, 134, 135, 136, 137, 138], 10, true);
    
    boss.animations.add('test', [5, 130, 131], 1, true);
    
    boss.animations.add('attack2Left', [140, 141, 142, 143, 144], 10, true);
    
    boss.animations.add('attack3Left', [150, 151, 152, 153, 154, 155], 10, true);
    
    boss.animations.add('attack4Left', [160, 161, 162, 163, 164, 165, 166, 167, 168], 10, true);
    
    boss.animations.add('damage1Left', [170, 171, 172], 10, true);
    
    boss.animations.add('damage2Left', [180, 181, 182], 10, true);
    
    boss.animations.add('deathLeft', [190, 191, 192, 193, 194, 195], 10, true);
    
    // regularRight set size
    boss.body.setSize(33, 42, 28, 22);
        
    mushroomCounter = 0



    cursors = game.input.keyboard.createCursorKeys();
    projectiles=game.add.group();
    projectiles.enableBody=true;
    bullet=projectiles.create(0,0,'projectile');
   	bullet.kill();
   	
   	bullet.animations.add('moving',[0,1,2,3,4,5,6,7],10,true);
    
    
    attackBoxes=game.add.group();
    attackBoxes.enableBody=true;
    attackBox=projectiles.create(0,0,'130');
    attackBox.kill();
    
    
    fireButton=game.input.keyboard.addKey(Phaser.KeyCode.SPACEBAR);

    scoreText = game.add.text(16, 16, 'score: '+ score, { fontSize: '32px', fill: '#000' });
    cursors = game.input.keyboard.createCursorKeys();
    
    jumpSound = game.add.audio('jump');
    hitSound = game.add.audio('hit');
    collectSound = game.add.audio('collect');

    playerdirection="right";
    enemyVuln=true;
    notAttacking=true;
    isDead=false;
    movement = 1
    cycle = 0
    actionList = ["idle", "move", "move", "attack1", "attack2", "attack3", "attack4"] //"damage1", "damage2", "death"]
    action = 0
    
    startPhase = 350
    
    ticks = 75
    
    appear = 0
    
    playerHealth = game.add.text(player.x, player.y-8, 'HP: <'+player.health +'>' ,{ fontSize: '16px', fill: '#000' });

    isAttacking = 0
    
    guardvisual= game.add.sprite(0,0,'uptime');
    guardvisual.animations.add('activation',[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16],20,false);
    guardvisual.kill();

    timeTilGuard=0;
    
},


update: function(){
    
    hitboxCreate()
    
    
    
    movement = enemyDirection(player, boss, movement)
    startPhase++
    if (startPhase == 351){
        whatAnimate(movement, 'idle', boss)
        startPhase = 0
    }
    if (startPhase == ticks){
        action = getRandomInt(actionList.length)
        //console.log(actionList[action])
        whatAnimate(movement, actionList[action], boss)
        
        startPhase = 0
        if (actionList[action] == "idle"){
            ticks = 50
        }
        if (actionList[action] == "move"){
            ticks = 75
        }
        if (actionList[action] == "attack1"){
            ticks = 50
        }
        if (actionList[action] == "attack2"){
            ticks = 50
        }
        if (actionList[action] == "attack3"){
            ticks = 50
        }
        if (actionList[action] == "attack4"){
            ticks = 50
        }   
    }
    
    
    if (playerVuln){
        game.physics.arcade.overlap(player,attackBoxes,toKill,null,this);
    }
    

    game.physics.arcade.overlap(bullet,boss,weaponInteraction,null,this);
    game.physics.arcade.collide(boss, platforms);
    game.physics.arcade.overlap(player, boss, enemyInteraction, null, this);
    game.physics.arcade.collide(player, platforms, platformCollide);
    game.physics.arcade.collide(items,platforms);
    game.physics.arcade.overlap(player,items,getItem,null,this);
    
    playerHealth.x=player.x-40;
    playerHealth.y=player.y-50;
    playerHealth.text='HP: <'+player.health+'>';
    
    

    if(!cursors.left.isDown && !cursors.right.isDown){
        player.body.velocity.x=0;
    }

    if (cursors.left.isDown)
    {
        playerdirection= "left";
        player.body.velocity.x = -150;
        player.anchor.setTo(.5,.5);
        player.scale.x =-1.5;
        if(player.body.velocity.y==0){
            player.animations.play('walk');
        }
        
    }

    else if (cursors.right.isDown)
    {
        playerdirection= "right";
     player.body.velocity.x = 150;
     player.anchor.setTo(.5,.5);
     player.scale.x =1.5;
     if(player.body.velocity.y==0){
        player.animations.play('walk');
     }
     
    }


    else if( player.body.velocity.x==0 && player.body.velocity.y==0 && notAttacking && !isDead)
    {
        player.animations.play('idle');
    }
    
    cursors.down.onDown.addOnce(guard,this);
    function guard(){

        if(timeTilGuard==0){
            playerVuln = false;
            player.tint= 0xD3D3D3;   
            game.time.events.add(1000, (function() {
                playerVuln=true;
                player.tint=0xFFFFFF;
            }), this); 
            timeTilGuard=240;    
        
        }
    }
    
    if(timeTilGuard>0){
        if(timeTilGuard==1){
            visual=game.add.sprite(player.x-40,player.y,'uptime');
            visual.scale.setTo(2,1.5)
            visual.animations.add('activation',[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16],60,false)
            visual.animations.play('activation');
            visual.lifespan=700;
        }
        timeTilGuard=timeTilGuard-1;
    }
    
    
    cursors.up.onDown.add(jumpCheck);
    
    
    fireButton.onDown.addOnce(shoot,this);

    
    function toKill(){
        //console.log("u were indeed just hit")
        player.damage(1);
        
        playerVuln=false;
        
        //console.log("player invulnerable");
        game.time.events.add(1000, (function() {
            playerVuln = true;
            //console.log("player vulnerable");
        }), this); 
        
           
        if(player.health==0){
            game.state.start('overworldstate');
        }
    }
    
    function shoot() {
        notAttacking=false;
        player.animations.play('attack');
        
            
       
        	var bulletDirection=playerdirection;
            
        	if(bulletDirection=="right"){
            		bullet=projectiles.create(player.x,player.y-25,'projectile');
            		bullet.lifespan=700;
            		bullet.scale.setTo(2,2);
            		
                    
            		bullet.animations.play('moving');
            		bullet.body.velocity.x=375
        	}else if( bulletDirection="left"){
            		bullet=projectiles.create(player.x,player.y-25,'projectile');
            		bullet.lifespan=700;
            		bullet.scale.setTo(-2,2);
            		
            		bullet.animations.play('moving');
            		bullet.body.velocity.x=-375;
            		bullet.scale.x= -2;
        	}

        game.time.events.add(200, (function() {    
            notAttacking=true;
        }), this); 

        
    }

    
    function jumpCheck() {
        if((jumpCount < 1) && (player.body.touching.down)){
            jump();
           jumpHeight=0.66;
            jumpSound.play();
            
        }
        if((jumpCount < 2) && (!player.body.touching.down)){
            jump();
            jumpSound.play()
  
        }

    }

    function jump(){
       
        jumpCount ++;
        player.body.velocity.y = -350*jumpHeight;
        player.animations.play('doublejump');
        jumpSound.play();
    }

    
    
    if (player.body.velocity.y >0){
        player.animations.play('descending');
    }
    var enterKey = game.input.keyboard.addKey(Phaser.Keyboard.ENTER);
    var attacking
        
    function platformCollide(){
    
        if(player.body.touching.down){
            jumpCount = 0;
            jumpHeight=1;
        }
        
    }
    function enemyInteraction (player, enemy) {
        
        if(player.body.touching.down && enemy.body.touching.up ){
            if(enemyVuln){
                if(enemy.health==1){
                    score += 1;
                    scoreText.text = "Score: " + score;
                }
                //console.log("detect goomba");
                enemy.damage(1);
                hitSound.play();
                enemyVuln=false;
                game.time.events.add(4000, (function() {
                    enemyVuln = true;
                  //  console.log("enemy vulnerable");
                }), this); 
            }
            enemy.body.velocity.setTo(-200,400);
            jumpCount=1;
            jumpHeight=0.33;
            jump();
            jumpCount=1;
            jumpHeight=0.66;
            
            
        }else {if(playerVuln){
           // console.log("detect damage");
           if(player.health==1){
            
            isDead=true;
            player.animations.play('perish'); 
            game.time.events.add(2000,function(){
                console.log('trying to animate')
                
                game.time.events.add(1000,function(){
                    console.log('murder committed')
                    game.state.start('overworldstate');});
                
            });
            
           }
           
           player.damage(1);
           playerVuln=false;
           //console.log("player invulnerable");
           player.animations.play('hurt');
           game.time.events.add(700, (function() {
                playerVuln = true;
                //console.log("player vulnerable");
           }), this); 
           
           
           
        }
    }
    }


    function weaponInteraction(bullet,enemy){
        if(enemy.health==1){
            score += 1;
            scoreText.text = "Score: " + score;
        }
        enemy.damage(1);
        bullet.kill();
        
    }
    function enemyDirection(player, enemy, movement){
        playersXCords = player.body.x
        enemyXCords = enemy.body.x
        //xDistanceAbs = Math.abs(enemyXCords - playersXCords)
        
        if (enemyXCords - playersXCords >= 0){
            return (1)
        }
        else {
            return (2)
        }
    }
    
    
    
    function airLineOfSight (player, enemy, enemyCords, enemySight, enemySpeed){
        playersXCords = player.body.x
        playersYCords = player.body.y
        enemyXCords = enemy.body.x
        enemyYCords = enemy.body.y
        xDistanceAbs = Math.abs(enemyXCords - playersXCords)
        yDistanceAbs = Math.abs(enemyYCords - playersYCords)
        xDistance = enemyXCords - playersXCords
        yDistance = enemyYCords - playersYCords
        if (xDistanceAbs <= enemySight[0] && yDistanceAbs <= enemySight[0]){
            
            
            if (xDistance <= 0 && yDistance <= 0){
                enemy.anchor.setTo(.5,.5);
                enemy.scale.x =-1;
                enemy.body.velocity.x = +enemySpeed[0]
                enemy.body.velocity.y = +enemySpeed[1]
            }
            else if (xDistance > 0 && yDistance > 0){
                enemy.anchor.setTo(.5,.5);
                enemy.scale.x =1;
                enemy.body.velocity.x = -enemySpeed[0]
                enemy.body.velocity.y = -enemySpeed[1]
            }
            else if (xDistance <= 0 && yDistance > 0){
                enemy.anchor.setTo(.5,.5);
                enemy.scale.x =-1;
                enemy.body.velocity.x = +enemySpeed[0]
                enemy.body.velocity.y = -enemySpeed[1]
            }
            else if (xDistance > 0 && yDistance <= 0){
                enemy.body.velocity.x = -enemySpeed[0]
                enemy.body.velocity.y = +enemySpeed[1]
            }
        }
        else if (enemyXCords == enemyCords[0] && enemyYCords == enemyCords[1]){
            enemy.anchor.setTo(.5,.5);
            enemy.scale.x =1;
            enemy.body.velocity.x = 0
            enemy.body.velocity.y = 0    
        }
        else {
            if (enemyXCords >= enemyCords[0]){
                enemy.body.velocity.x = -enemySpeed[0]
            }
            else {
                enemy.body.velocity.x = +enemySpeed[0]
            }
            if (enemyYCords >= enemyCords[1]){
                enemy.body.velocity.y = -enemySpeed[1]
            }
            else {
                enemy.body.velocity.y = +enemySpeed[1]
            }
            
        }
                 
        
        
    }
    


    function getItem(player, items){
        items.kill();
        score += 1;
        scoreText.text = "Score: " + score;
        console.log(score)
        collectSound.play();
    }
    function groundMovement (enemy, counter, xCords, xDist, speed){
    
        enemyPosition = enemy.body.x
        farLeft = xCords - xDist
        farRight = xCords + xDist
        console.log (enemyPosition)
        if (counter == 0) {
            enemy.body.velocity.x = -speed
            if (enemyPosition <= farLeft) {
            
                counter += 1
            }
        
        }
        else if (counter == 1) {
            enemy.body.velocity.x = +speed
            if (enemyPosition >= farRight){
            
                counter -= 1
            }
        
        }
        return counter

    }
    
    function Phase(startPhase){
        console.log(startPhase)
    }
    
    function getRandomInt(max) {
        return Math.floor(Math.random() * max);
    }
    
    function hitboxCreate(){
        
        if (boss.frame == 130){
            box=attackBoxes.create(boss.x+289.8, boss.y+90,'130')
            box.lifespan=1;
    
        }
        if (boss.frame == 131){
        
            box=attackBoxes.create(boss.x+39, boss.y+21,'131-1')
            box1=attackBoxes.create(boss.x+39, boss.y+21,'131-2')
            box.lifespan=1;
            box1.lifespan=1;
        
    
        }
    
        if (boss.frame == 132){
        
            box=attackBoxes.create(boss.x+49, boss.y+21,'132-1')
            box1=attackBoxes.create(boss.x+49, boss.y+21,'132-2')
            box.lifespan=1;
            box1.lifespan=1;
        
    
        }
    
        if (boss.frame == 133){
        
            box=attackBoxes.create(boss.x+49, boss.y+30,'133')
            box.lifespan=1;
        
        
    
        }
    
        if (boss.frame == 134){
        
            box=attackBoxes.create(boss.x+58, boss.y+164,'134')
            box.lifespan=1;
        
        
    
        }
    
        if (boss.frame == 135 ){
        
            box=attackBoxes.create(boss.x+88, boss.y+262,'135')
            box.lifespan=1;
        
        
    
        }
    
        if (boss.frame == 136 ){
        
            box=attackBoxes.create(boss.x+88, boss.y+262,'136')
            box.lifespan=1;
        }
    
    
    

    
        if (boss.frame == 140 ){
        
            box=attackBoxes.create(boss.x+76, boss.y+172,'140')
            box.lifespan=1;
        }
        if (boss.frame == 141 ){
        
            box=attackBoxes.create(boss.x+25, boss.y+205,'141')
            box.lifespan=1;
        }
        if (boss.frame == 142 ){
        
            box=attackBoxes.create(boss.x+30, boss.y+205,'142')
            box.lifespan=1;
        }
        if (boss.frame == 143 ){
        
            box=attackBoxes.create(boss.x+30, boss.y+205,'143')
            box.lifespan=1;
        }
        if (boss.frame == 144 ){
        
            box=attackBoxes.create(boss.x+40, boss.y+205,'144')
            box.lifespan=1;
        }
        if (boss.frame == 150 ){
        
            box=attackBoxes.create(boss.x+275, boss.y+75,'150')
            box.lifespan=1;
        }
        if (boss.frame == 151 ){
        
            box=attackBoxes.create(boss.x+275, boss.y+68,'151')
            box.lifespan=1;
        }
        if (boss.frame == 152 ){
        
            box=attackBoxes.create(boss.x+275, boss.y+62,'152')
            box.lifespan=1;
        }
        if (boss.frame == 153 ){
        
            box=attackBoxes.create(boss.x+275, boss.y+50,'153')
            box.lifespan=1;
        }
        if (boss.frame == 154 ){
        
            box=attackBoxes.create(boss.x+275, boss.y+58,'154')
            box.lifespan=1;
        }
        if (boss.frame == 155 ){
        
            box=attackBoxes.create(boss.x+275, boss.y+70,'155')
            box.lifespan=1;
        }
        if (boss.frame == 160 ){
        
            box=attackBoxes.create(boss.x+72, boss.y+178,'160')
            box.lifespan=1;
        }
        if (boss.frame == 161 ){
        
            box=attackBoxes.create(boss.x+58, boss.y+178,'161')
            box.lifespan=1;
        }
        if (boss.frame == 162 ){
        
            box=attackBoxes.create(boss.x+58, boss.y+170,'162')
            box.lifespan=1;
        }
        if (boss.frame == 163 ){
        
            box=attackBoxes.create(boss.x+125, boss.y+240,'163')
            box.lifespan=1;
        }
        if (boss.frame == 164 ){
        
            box=attackBoxes.create(boss.x+215, boss.y+215,'164')
            box.lifespan=1;
        }
        if (boss.frame == 165 ){
        
            box=attackBoxes.create(boss.x+20, boss.y+230,'165')
            box.lifespan=1;
        }
        if (boss.frame == 166 ){
        
            box=attackBoxes.create(boss.x+43, boss.y+260,'166')
            box.lifespan=1;
        }
        if (boss.frame == 167 ){
        
            box=attackBoxes.create(boss.x+80, boss.y+262,'167')
            box.lifespan=1;
        }
        if (boss.frame == 168 ){
        
            box=attackBoxes.create(boss.x+88, boss.y+262,'168')
            box.lifespan=1;
        }
    
    
    
    
        if (boss.frame == 30){

            box=attackBoxes.create(boss.x+25, boss.y+90,'130')
            box.lifespan=1;

    
        }
        if (boss.frame == 31){
        
            box=attackBoxes.create(boss.x+54, boss.y+21,'131-1')
            box1=attackBoxes.create(boss.x+260, boss.y+21,'131-2')
            box.lifespan=1;
            box1.lifespan=1;
        
    
        }
    
        if (boss.frame == 32){
        
            box=attackBoxes.create(boss.x+60, boss.y+21,'132-1')
            box1=attackBoxes.create(boss.x+265, boss.y+21,'132-2')
            box.lifespan=1;
            box1.lifespan=1;
        
    
        }
    
        if (boss.frame == 33){
        
            box=attackBoxes.create(boss.x+238, boss.y+30,'133')
            box.lifespan=1;
        
        
    
        }
    
        if (boss.frame == 34){
        
            box=attackBoxes.create(boss.x+245, boss.y+164,'134')
            box.lifespan=1;
        
        
    
        }
    
        if (boss.frame == 35 ){
        
            box=attackBoxes.create(boss.x+248, boss.y+262,'135')
            box.lifespan=1;
        
        
    
        }
    
        if (boss.frame == 36 ){
        
            box=attackBoxes.create(boss.x+248, boss.y+262,'136')
            box.lifespan=1;
        }
    
    
    

    
        if (boss.frame == 40 ){
        
            box=attackBoxes.create(boss.x+279, boss.y+172,'140')
            box.lifespan=1;
        }
        if (boss.frame == 41 ){
        
            box=attackBoxes.create(boss.x+284, boss.y+205,'141')
            box.lifespan=1;
        }
        if (boss.frame == 42 ){
        
            box=attackBoxes.create(boss.x+279, boss.y+205,'142')
            box.lifespan=1;
        }
        if (boss.frame == 43 ){
        
            box=attackBoxes.create(boss.x+279, boss.y+205,'143')
            box.lifespan=1;
        }
        if (boss.frame == 44 ){
        
            box=attackBoxes.create(boss.x+279, boss.y+205,'144')
            box.lifespan=1;
        }
        if (boss.frame == 50 ){
        
            box=attackBoxes.create(boss.x+110, boss.y+75,'150')
            box.lifespan=1;
        }
        if (boss.frame == 51 ){
        
            box=attackBoxes.create(boss.x+110, boss.y+68,'151')
            box.lifespan=1;
        }
        if (boss.frame == 52 ){
        
            box=attackBoxes.create(boss.x+110, boss.y+62,'152')
            box.lifespan=1;
        }
        if (boss.frame == 53 ){
        
            box=attackBoxes.create(boss.x+110, boss.y+50,'153')
            box.lifespan=1;
        }
        if (boss.frame == 54 ){
        
            box=attackBoxes.create(boss.x+110, boss.y+58,'154')
            box.lifespan=1;
        }
        if (boss.frame == 55 ){
        
            box=attackBoxes.create(boss.x+110, boss.y+70,'155')
            box.lifespan=1;
        }
        if (boss.frame == 60 ){
        
            box=attackBoxes.create(boss.x+279, boss.y+178,'160')
            box.lifespan=1;
        }
        if (boss.frame == 61 ){
        
            box=attackBoxes.create(boss.x+279, boss.y+178,'161')
            box.lifespan=1;
        }
        if (boss.frame == 62 ){
        
            box=attackBoxes.create(boss.x+279, boss.y+170,'162')
            box.lifespan=1;
        }
        if (boss.frame == 63 ){
        
            box=attackBoxes.create(boss.x+41, boss.y+240,'163')
            box.lifespan=1;
        }
        if (boss.frame == 64 ){
        
            box=attackBoxes.create(boss.x-0, boss.y+215,'164')
            box.lifespan=1;
        }
        if (boss.frame == 65 ){
        
            box=attackBoxes.create(boss.x+247, boss.y+230,'165')
            box.lifespan=1;
        }
        if (boss.frame == 66 ){
        
            box=attackBoxes.create(boss.x+247, boss.y+260,'166')
            box.lifespan=1;
        }
        if (boss.frame == 67 ){
        
            box=attackBoxes.create(boss.x+245, boss.y+262,'167')
            box.lifespan=1;
        }
        if (boss.frame == 68 ){
        
            box=attackBoxes.create(boss.x+245, boss.y+262,'168')
            box.lifespan=1;
        }
    }
    
    function whatAnimate (movement, action, enemy){
        
        
    
    
        dictLeft = {
            idle : "idleLeft",
            move : "moveLeft",
            taunt : "tauntLeft",
            attack1 : "attack1Left",
            attack2 : "attack2Left",
            attack3 : "attack3Left",
            attack4 : "attack4Left",
            damage1 : "damage1Left",
            damage2 : "damage2Left",
            death : "deathLeft",

            
        }
        
        dictRight = {
            idle : "idleRight",
            move : "moveRight",
            taunt : "tauntRight",
            attack1 : "attack1Right",
            attack2 : "attack2Right",
            attack3 : "attack3Right",
            attack4 : "attack4Right",
            damage1 : "damage1Right",
            damage2 : "damage2Right",
            death : "deathRight",
            
        }
        
        
        if (movement == 1){
            
            
            animate = dictLeft[action]
            
        }
        if (movement == 2){
            
            animate = dictRight[action]
            
        }
        
        if (animate == "idleLeft" || animate == "moveLeft" || animate == "tauntLeft" || animate == "damage1Left" || animate == "damage2Left"){
            
            enemy.body.setSize(30, 42, 35, 22)
            enemy.animations.play(animate)
            
            if (animate == "idleLeft" || animate == "tauntLeft" || animate == "damage1Left" || animate == "damage2Left"){
                enemy.body.velocity.x = 0
            }
            else if (animate == "moveLeft"){
                enemy.body.velocity.x = -200
                
                
            }
        }
        if (animate == "attack1Left") {
            //enemy.body.setSize(56, 57, 10, 7)
            enemy.body.setSize(30, 42, 35, 22)
            enemy.animations.play(animate)
            enemy.body.velocity.x = 0
            
            
            
            //box.kill()
            
        }
        if (animate == "attack2Left") {
            enemy.body.setSize(30, 42, 35, 22)
            //enemy.body.setSize(56, 42, 10, 22)
            enemy.animations.play(animate)
            enemy.body.velocity.x = 0
            
//            box=attackBoxes.create(enemy.x-90, enemy.y-10,'attackVisual')
//            box.scale.setTo(.25,.25);
            //box.kill()
            
        }
        if (animate == "attack3Left") {
            enemy.body.setSize(30, 42, 35, 22)
            //enemy.body.setSize(38, 53, 35, 11)
            enemy.animations.play(animate)
            enemy.body.velocity.x = 0
            
//            box=attackBoxes.create(enemy.x-90, enemy.y-40,'attackVisual')
//            box.scale.setTo(.25,.25);
            //box.kill()
            
        }
        if (animate == "attack4Left") {
            enemy.body.setSize(30, 42, 35, 22)
            //enemy.body.setSize(87, 42, 7, 22)
            enemy.animations.play(animate)
            enemy.body.velocity.x = 0
            
//            box=attackBoxes.create(enemy.x-90, enemy.y-60,'attackVisual')
//            box.scale.setTo(.25,.25);
//            //box.kill()
            
        }
        
    
        if (animate == "idleRight" || animate == "moveRight" || animate == "tauntRight" || animate == "damage1Right" || animate == "damage2Right"){
            enemy.body.setSize(33, 42, 28, 22)
            enemy.animations.play(animate)
            if (animate == "idleRight" || animate == "tauntRight" || animate == "damage1Right" || animate == "damage2Right"){
                enemy.body.velocity.x = 0
            }
            else if (animate == "moveRight"){
                enemy.body.velocity.x = +200
                
            }
        }
        if (animate == "attack1Right") {
            //enemy.body.setSize(60, 57, 28, 7)
            
            enemy.body.setSize(33, 42, 28, 22)
            enemy.animations.play(animate)
            enemy.body.velocity.x = 0
        }
        if (animate == "attack2Right") {
            //enemy.body.setSize(60, 42, 28, 22)
            enemy.body.setSize(33, 42, 28, 22)
            enemy.animations.play(animate)
            enemy.body.velocity.x = 0
        }
        if (animate == "attack3Right") {
            //enemy.body.setSize(37, 53, 24, 11)
            enemy.body.setSize(33, 42, 28, 22)
            enemy.animations.play(animate)
            enemy.body.velocity.x = 0
        }
        if (animate == "attack4Right") {
            //enemy.body.setSize(87, 42, 2, 22)
            enemy.body.setSize(33, 42, 28, 22)
            enemy.animations.play(animate)
            enemy.body.velocity.x = 0
        }
        
//        cycle ++
//        if (cycle > 9){
//            cycle = 0
//        }
//        
//        startPhase ++
        
        
        
    }
    
    if (score == 1) {
        game.state.start('winState');

    }
    
}
}