var deathState = {
    preload: function(){
        console.log('deathstate');
        
        game.load.image('deathBG', 'assets/DeadForestTemp.png');
        game.load.image('deathTXT', 'assets/deathTXT.png');
        game.load.image('cont', 'assets/cont.png');
    },
    
    create: function(){
    
        bg = this.game.add.sprite(0,0,'deathBG');
        bg.height = game.height;
        bg.width = game.width;
        game.add.sprite(350, 300, 'deathTXT');
        game.add.sprite(900, 550, 'cont');
        
        var enterKey = game.input.keyboard.addKey(Phaser.Keyboard.ENTER);
        
        enterKey.onDown.addOnce(this.play, this);
    },
    
    play: function(){
        game.state.start('overworldstate');
    }
    
}