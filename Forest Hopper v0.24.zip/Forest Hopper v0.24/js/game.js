var game = new Phaser.Game(1058, 600, Phaser.AUTO, 'gameDiv');
game.state.add('boot',bootState);

game.state.add('load',loadscreen);

game.state.add('mainmenu',menustate);

game.state.add('gamestate',gamestate);

game.state.add('tutorialstate', tutorialstate);

game.state.add('level1', level1);

game.state.add('level2', level2);

game.state.add('level3', level3);

game.state.add('overworldstate', overworldstate);

game.state.add('level1Boss', level1Boss);

game.state.add('level2Boss', level2Boss);

game.state.add('level3Boss', level3Boss);

game.state.add('level4Boss', level4Boss);

game.state.add('level5Boss', level5Boss);

game.state.add('deathState', deathState);

game.state.add('winState', winState);

game.state.add('getReadyState1', getReadyState1);

game.state.add('getReadyState2', getReadyState2);

game.state.add('getReadyState3', getReadyState3);

game.state.add('getReadyState4', getReadyState4);

console.log("states added");
game.state.start('boot');