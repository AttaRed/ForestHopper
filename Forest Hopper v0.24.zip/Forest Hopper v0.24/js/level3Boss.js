var level3Boss ={

    

preload:function() {

    game.load.image('ground', 'assets/graveyardground.png');
    game.load.image('platform1', 'assets/graveyardplatform1.png');
    //game.load.image('platform2', 'assets/graveyardplatform2.png');
    game.load.image('bg', 'assets/graveyard.png');
    //game.load.spritesheet('player', 'assets/spritesheet.png', 96, 84);
    //game.load.spritesheet('player', 'assets/bunnywork.png', 46, 90, 59);
    
    game.load.spritesheet('player', 'assets/Warrior_Sheet-Effect.png', 69, 44);
    game.load.image('bag','assets/bag.png');
    //game.load.spritesheet('bat', 'assets/bat.png', 46, 30);
    //game.load.spritesheet('mushroom', 'assets/mushroom.png', 32, 32)
    game.load.spritesheet('projectile', 'assets/Projectile 2.png',32,32)
    
    game.load.spritesheet('elder', 'assets/Elder Dragon Pink Sprite Sheet.png', 192, 96)
    
    game.load.spritesheet('firebeamHead', 'assets/Fire Beam/Fire Beam.png', 32, 32)
    game.load.spritesheet('firebeamBody', 'assets/Fire Beam/Fire Beam upperside.png', 32, 32)

    
    game.load.image('invisibleHitBox', 'assets/invisibleHitBox.png');
    
    game.load.image('16','assets/dragonHitboxes/16.jpeg');
    game.load.image('17','assets/dragonHitboxes/17.jpeg');
    game.load.image('18','assets/dragonHitboxes/18.jpeg');
    game.load.image('19','assets/dragonHitboxes/19.jpeg');
    game.load.image('20','assets/dragonHitboxes/20.jpeg');
    game.load.image('21','assets/dragonHitboxes/21.jpeg');
    game.load.image('22','assets/dragonHitboxes/22.jpeg');
    game.load.image('23','assets/dragonHitboxes/23.jpeg');
    
    game.load.audio('jump', 'assets/Jump 1.wav');
    game.load.audio('hit', 'assets/Hit damage 1.wav');
    game.load.audio('collect', 'assets/Fruit collect 1.wav');
    game.load.spritesheet('uptime','assets/GuardUp.png',32,32);
        
    var player;
    var platforms;
    var cursors;
    var items;
    var score;
    var scoreText;
    var canDouble=1;
    var enterKey = game.input.keyboard.addKey(Phaser.Keyboard.ENTER);
    var boss
    var mushroomCounter;
    var projectiles;
    var bullet;
    var floor;
    
    var movement;
    var action;
    var actionList;
    
    var playerVuln;
    var enemyVuln;
    
    var playerHealth;
    var timeTilGuard;
},
    
create: function(){
    
    game.world.setBounds(0, 0, 1058, 600);


    score=0;

    this.keyboard = game.input.keyboard;

    background1 = game.add.sprite(0, 0, 'bg')
//    background2 = game.add.sprite(0, 600, 'bg')
//    background3 = game.add.sprite(1058, 0, 'bg')
//    background4 = game.add.sprite(1058, 600, 'bg')
    background1.scale.setTo(4,4)
    platforms = game.add.group();
    platforms.enableBody = true;
    var ground = platforms.create(0, 525, 'ground');
    ground.scale.setTo(2, 2);
    ground.body.immovable = true;
    var ledge = platforms.create(2300,800, 'platform1');
    ledge.body.immovable = true;
    //ledge = platforms.create(400, 320, 'platform2');
    //ledge.body.immovable = true;
    //ledge = platforms.create(10, 100, 'platform1');
    //ledge.body.immovable = true;

    
    items=game.add.group();
    items.enableBody = true;
//    for (var i = 0;i<6 ;i++){
//        var item= items.create(game.world.randomX, game.world.randomY*0.7, 'bag')
//        item.body.gravity.y=300;
//        item.body.bounce.y=0.3 + Math.random()*0.2;
//        item++;
//    }

    player = game.add.sprite(96, 400, 'player');
    camera = game.camera.follow(player, Phaser.Camera.FOLLOW_PLATFORMER);

    
    player.scale.setTo(1.5, 1.5);
    player.health=5;
    playerVuln=true;
    
    game.physics.arcade.enable(player);
    
    player.body.gravity.y = 300;
    
    player.body.setSize(18,33,18,10);
    player.body.collideWorldBounds = true;

    player.animations.add('perish',[26,27,28,29,30,31,32,33,34,35,36],10,false);
    player.animations.add('walk', [6,7,8,9,10,11,12,13], 20, true);
    player.animations.add('hurt',[37],10,false);
    player.animations.add('idle', [0,1,2,3,4,5], 10, true);
    player.animations.add('doublejump',[41, 42, 43, 44, 45],10,true);
    player.animations.add('descending',[46,47,48],10,true);
    player.animations.add('attack',[16,17,18,19,20],20,false);
    
    boss = game.add.sprite(800, 200, 'elder');
    
    boss.scale.setTo(4.6, 4.6);
    boss.health=20;
    
    game.physics.arcade.enable(boss);
    boss.body.gravity.y = 300;
    boss.body.collideWorldBounds = true;
    
    boss.anchor.setTo(.5,.5);
    boss.scale.x =-4.6;
    boss.animations.add('all', [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 56, 57, 58, 59, 60, 61, 62, 63, 63, 63, 63, 63, 63, 63, 63], 10, true);
    
    boss.animations.add('idle', [0, 1, 2, 3, 4, 5, 6, 7], 10, true);
    
    boss.animations.add('run', [8, 9, 10, 11, 12, 13, 14, 15], 10, true);
    
    boss.animations.add('attack1', [16, 17, 18, 19, 20, 21, 22, 23], 10, false);
    
    boss.animations.add('startCharge', [24, 25, 26, 27, 28, 29, 30, 31], 10, true);
    
    //boss.animations.add('attack2', [32, 33, 34, 35, 36, 37, 38, 39], 10, true);
    boss.animations.add('attack2', [24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 33, 34, 35, 36, 37, 38, 39, 33, 34, 35, 36, 37, 38, 39, 33, 34, 35, 36, 37, 31, 30, 29, 30, 31, 33, 34, 35, 36, 37, 38, 39, 33, 34, 35, 36, 37, 31, 30, 29, 28, 27, 26, 25, 24, 24, 24], 10, true);
    
    boss.animations.add('chargeEnd', [40, 41, 42, 43, 44, 45, 46, 47], 10, true);
    
    boss.animations.add('damage', [48, 49, 50, 51], 10, true);
    
    boss.animations.add('death', [56, 57, 58, 59, 60, 61, 62, 63], 10, true);
    
    
    
    
    //boss.animations.add('dead', [56, 57, 58, 59, 60, 61, 62, 63], 2, true);
    
//    
//    boss.animations.add('attack', [60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71], 7, true);
    
    
    
    // regularRight set size
    //boss.body.setSize(74, 31, 61, 65);
    
    boss.body.setSize(61, 65, 74, 31);
    
    
    wall = game.add.sprite(boss.body.x-800,boss.body.y+0, 'invisibleHitBox')
    wall.enableBody-true;
    
    cursors = game.input.keyboard.createCursorKeys();
    projectiles=game.add.group();
    projectiles.enableBody=true;
    bullet=projectiles.create(0,0,'projectile');
    bullet.kill();
    bullet.animations.add('fired',[0,1,2,3,4],10,false);
    bullet.animations.add('moving',[5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20],10,true);
    
    attackBoxes=game.add.group();
    attackBoxes.enableBody=true;
    attackBox=projectiles.create(0,0,'16');
    attackBox.kill();
    
    beam=game.add.group();
    beam.enableBody=true;
    beamPart=projectiles.create(1000,0,'firebeamHead');
    beamPart.kill();
    
    beamPart.animations.add('creation', [9, 8, 7, 6, 5, 4, 3, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0], 100, true);
    beamPart.animations.add('hold', [0, 0, 0, 0, 0, 0, 0, 0, 0], 100, true);
    beamPart.animations.add('firing', [1], 1, true);
    
    
    fireButton=game.input.keyboard.addKey(Phaser.KeyCode.SPACEBAR);

    scoreText = game.add.text(16, 16, 'score: '+ score, { fontSize: '32px', fill: '#000' });
    cursors = game.input.keyboard.createCursorKeys();
    
    jumpSound = game.add.audio('jump');
    hitSound = game.add.audio('hit');
    collectSound = game.add.audio('collect');

    playerdirection="right";
    enemyVuln=true;
    notAttacking=true;
    isDead=false;
    movement = 1
    cycle = 0
    actionList = ["idle", "attack1", "attack2", "idle"] //"damage1", "damage2", "death"]
    action = 0
    
    startPhase = 350
    
    ticks = 100
    
    appear = 0
    
    playerHealth = game.add.text(player.x, player.y-8, 'HP: <'+player.health +'>' ,{ fontSize: '16px', fill: '#000' });
    
    beamPhase = 0
    buildUp = 0
    
    killBeamChecker = 0
    beamCheckerChecker = 0
    
    guardvisual= game.add.sprite(0,0,'uptime');
    guardvisual.animations.add('activation',[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16],20,false);
    guardvisual.kill();

    timeTilGuard=0;
},


update: function(){
    
    
    //boss.animations.play("attack2")
    
    if (boss.frame == 16 ){
        
        box=attackBoxes.create(boss.x-155, boss.y+161,'16')
        box.lifespan=1;
    }
    
    if (boss.frame == 17 ){
        
        box=attackBoxes.create(boss.x-139, boss.y+156,'17')
        box.lifespan=1;
    }
    
    if (boss.frame == 18 ){
        
        box=attackBoxes.create(boss.x-175, boss.y+120,'18')
        box.lifespan=1;
    }
    
    if (boss.frame == 19 ){
        
        box=attackBoxes.create(boss.x-215, boss.y+70,'19')
        box.lifespan=1;
    }
    
    if (boss.frame == 20 ){
        
        box=attackBoxes.create(boss.x-215, boss.y+35,'20')
        box.lifespan=1;
    }
    
    if (boss.frame == 21 ){
        
        box=attackBoxes.create(boss.x-307, boss.y+35,'21')
        box.lifespan=1;
    }
    
    if (boss.frame == 22 ){
        
        box=attackBoxes.create(boss.x-340, boss.y+55,'22')
        box.lifespan=1;
    }
    
    if (boss.frame == 23 ){
        
        box=attackBoxes.create(boss.x-342, boss.y+55,'23')
        box.lifespan=1;
    }
    
    if (boss.frame == 24 && beamPhase == 0 ){
        
        beamPhase++
    }
    if (boss.frame == 32 && beamPhase == 1){//, 33, 34, 35, 36, 37, 38, 39 ){
        
        
        beamPart=beam.create(boss.x-162, boss.y+20,'firebeamHead')
        //beamPart.velocity
        beamPart.animations.add('creation', [9, 8, 7, 6, 5, 4, 3, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 100, false);
        beamPart.animations.add('firing', [9], 1, true);
        beamPart.animations.add('hold', [0, 0, 0, 0, 0, 0, 0, 0, 0], 100, true);
        beamPart.animations.play("creation")
        beamPart.body.velocity.x = 0
        
        beamPhase++
        //beamPart.lifespan=1000;
        
    }
//    if (boss.frame == 0 && beamPhase == 2 && buildUp == 0 ){
//        beamPart.animations.add('creation', [9, 8, 7, 6, 5, 4, 3, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 100, false);
//        beamPart.animations.add('firing', [1], 1, true);
//        //beamPart.animations.add('hold', [0, 0, 0, 0, 0, 0, 0, 0, 0], 100, true);
//        beamPart.animations.play("hold")
//    }
    
    if (buildUp == 0 && beamPhase == 2){
        game.time.events.add(3000, (function() {
            beamPart.body.velocity.x = -1500
            beamPart.animations.play("firing")
            
            game.time.events.add(1700, (function() {
                console.log("beamkiller triggered")
                killBeamChecker = 1

            }))
            
            //console.log(beamPhase,buildUp)
        }))
        buildUp++
    }
    if (boss.frame == 29 && beamPhase == 2 && buildUp == 1 ){
        
        beamPhase = 0
        buildUp = 0
    }
    
    
    if (killBeamChecker == 1 && beamCheckerChecker == 0){
        game.physics.arcade.overlap(wall,beamPartBody2,killBeam(wall,beamPartBody2),null,this);
        game.physics.arcade.overlap(wall,beamPartBody1,killBeam(wall,beamPartBody1),null,this);
        
        beamCheckerChecker = 1
        
        game.time.events.add(2900, (function() {
            
            console.log("beamkiller off")
            killBeamChecker = 0
            beamCheckerChecker = 0
        }))
        
    }
    
    if (beamPart.body.x > boss.body.x-2000 && beamPart.body.x < boss.body.x-190){
        beamPartBody1=beam.create(boss.x-162, boss.y+20,'firebeamBody')
        //beamPartBody1.lifespan(100)
        //beamPart.velocity
        beamPartBody1.animations.add('creation', [9, 8, 7, 6, 5, 4, 3, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 100, false);
        beamPartBody1.animations.add('firing', [1], 1, true);
        beamPartBody1.animations.add('hold', [0, 0, 0, 0, 0, 0, 0, 0, 0], 100, true);
        beamPartBody1.animations.play("firing")
        beamPartBody1.body.velocity.x = -1500
        
        beamPartBody2=beam.create(boss.x-175, boss.y+20,'firebeamBody')
        //beamPartBody2.lifespan(100)
        //beamPart.velocity
        beamPartBody2.animations.add('creation', [9, 8, 7, 6, 5, 4, 3, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 100, false);
        beamPartBody2.animations.add('firing', [1], 1, true);
        beamPartBody2.animations.add('hold', [0, 0, 0, 0, 0, 0, 0, 0, 0], 100, true);
        beamPartBody2.animations.play("firing")
        beamPartBody2.body.velocity.x = -1500
        
        //console.log(beamPartBody2.body.x)
        
        
    }

    
    
    
    
    
    
    movement = enemyDirection(player, boss, movement)
    startPhase++
    if (startPhase == 351){
        whatAnimate(movement, 'idle', boss)
        startPhase = 0
    }
    if (startPhase == ticks){
        action = getRandomInt(actionList.length)
        console.log(actionList[action])
        whatAnimate(movement, actionList[action], boss)
        
        startPhase = 0
        if (actionList[action] == "idle"){
            ticks = 100
        }

        if (actionList[action] == "attack1"){
            ticks = 50
        }
        if (actionList[action] == "attack2"){
            ticks = 300
        }

        
    }
    

    
    
    
    

    
    if (playerVuln){
        game.physics.arcade.overlap(player,attackBoxes,toKill,null,this);
        game.physics.arcade.overlap(player,beam,toKill,null,this);
    }
    
//    game.physics.arcade.overlap(wall,beamPartBody1,killBeam(wall,beamPartBody1),null,this);
    
    game.physics.arcade.overlap(bullet,boss,weaponInteraction,null,this);
    game.physics.arcade.collide(boss, platforms);
    game.physics.arcade.overlap(player, boss, enemyInteraction, null, this);

    game.physics.arcade.collide(player, platforms, platformCollide);

    game.physics.arcade.collide(items,platforms);
    game.physics.arcade.overlap(player,items,getItem,null,this);

    playerHealth.x=player.x-40;
    playerHealth.y=player.y-50;
    playerHealth.text='HP: <'+player.health+'>';
    
    if(!cursors.left.isDown && !cursors.right.isDown){
        player.body.velocity.x=0;
    }

    if (cursors.left.isDown)
    {
        playerdirection= "left";
        player.body.velocity.x = -150;
        player.anchor.setTo(.5,.5);
        player.scale.x =-1.5;
        if(player.body.velocity.y==0){
            player.animations.play('walk');
        }
        
    }

    else if (cursors.right.isDown)
    {
        playerdirection= "right";
     player.body.velocity.x = 150;
     player.anchor.setTo(.5,.5);
     player.scale.x =1.5;
     if(player.body.velocity.y==0){
        player.animations.play('walk');
     }
     
    }


    else if( player.body.velocity.x==0 && player.body.velocity.y==0 && notAttacking && !isDead)
    {
        player.animations.play('idle');
    }
    
    cursors.down.onDown.addOnce(guard,this);
    function guard(){

        if(timeTilGuard==0){
            playerVuln = false;
            player.tint= 0xD3D3D3;   
            game.time.events.add(1000, (function() {
                playerVuln=true;
                player.tint=0xFFFFFF;
            }), this); 
            timeTilGuard=240;    
        
        }
    }
    
    if(timeTilGuard>0){
        if(timeTilGuard==1){
            visual=game.add.sprite(player.x-40,player.y,'uptime');
            visual.scale.setTo(2,1.5)
            visual.animations.add('activation',[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16],60,false)
            visual.animations.play('activation');
            visual.lifespan=700;
        }
        timeTilGuard=timeTilGuard-1;
    }
    
    
    
    
    cursors.up.onDown.add(jumpCheck);
    
    fireButton.onDown.addOnce(shoot,this);
    
    function toKill(){
        //console.log("u were indeed just hit")
        player.damage(1);
        
        playerVuln=false;
        
        //console.log("player invulnerable");
        game.time.events.add(1000, (function() {
            playerVuln = true;
            //console.log("player vulnerable");
        }), this); 
        
           
        if(player.health==0){
            game.state.start('overworldstate');
        }
    }
    
    function shoot() {
        notAttacking=false;
        player.animations.play('attack');
        
            
       
        	var bulletDirection=playerdirection;
            
        	if(bulletDirection=="right"){
            		bullet=projectiles.create(player.x,player.y-25,'projectile');
            		bullet.lifespan=700;
            		bullet.scale.setTo(2,2);
            		
                    
            		bullet.animations.play('moving');
            		bullet.body.velocity.x=375
        	}else if( bulletDirection="left"){
            		bullet=projectiles.create(player.x,player.y-25,'projectile');
            		bullet.lifespan=700;
            		bullet.scale.setTo(-2,2);
            		
            		bullet.animations.play('moving');
            		bullet.body.velocity.x=-375;
            		bullet.scale.x= -2;
        	}

        game.time.events.add(200, (function() {    
            notAttacking=true;
        }), this); 

        
    }

    
    function jumpCheck() {
        if((jumpCount < 1) && (player.body.touching.down)){
            jump();
           jumpHeight=0.66;
            jumpSound.play();
            
        }
        if((jumpCount < 2) && (!player.body.touching.down)){
            jump();
            jumpSound.play()
  
        }

    }

    function jump(){
       
        jumpCount ++;
        player.body.velocity.y = -350*jumpHeight;
        player.animations.play('doublejump');
        jumpSound.play();
    }

    
    
    if (player.body.velocity.y >0){
        player.animations.play('descending');
    }
    var enterKey = game.input.keyboard.addKey(Phaser.Keyboard.ENTER);
    var attacking
        
    function platformCollide(){
    
        if(player.body.touching.down){
            jumpCount = 0;
            jumpHeight=1;
        }
        
    }
    
    
    function enemyInteraction (player, enemy) {
        
        if(player.body.touching.down && enemy.body.touching.up ){
            if(enemyVuln){
                if(enemy.health==1){
                    score += 1;
                    scoreText.text = "Score: " + score;
                }
                //console.log("detect goomba");
                enemy.damage(1);
                hitSound.play();
                enemyVuln=false;
                game.time.events.add(4000, (function() {
                    enemyVuln = true;
                  //  console.log("enemy vulnerable");
                }), this); 
            }
            //enemy.body.velocity.setTo(-200,400);
            jumpCount=1;
            jumpHeight=0.33;
            jump();
            jumpCount=1;
            jumpHeight=0.66;
            
            
        }else {if(playerVuln){
           // console.log("detect damage");
           if(player.health==1){
            
            isDead=true;
            player.animations.play('perish'); 
            game.time.events.add(2000,function(){
                console.log('trying to animate')
                
                game.time.events.add(1000,function(){
                    console.log('murder committed')
                    game.state.start('overworldstate');});
                
            });
            
           }
           
           player.damage(1);
           playerVuln=false;
           //console.log("player invulnerable");
           player.animations.play('hurt');
           game.time.events.add(700, (function() {
                playerVuln = true;
                //console.log("player vulnerable");
           }), this); 
           
           
           
        }
    }
    }


    function weaponInteraction(bullet,enemy){
        if(enemy.health==1){
            score += 1;
            scoreText.text = "Score: " + score;
        }
        enemy.damage(1);
        bullet.kill();
        
    }
    function enemyDirection(player, enemy, movement){
        playersXCords = player.body.x
        enemyXCords = enemy.body.x
        //xDistanceAbs = Math.abs(enemyXCords - playersXCords)
        
        if (enemyXCords - playersXCords >= 0){
            return (1)
        }
        else {
            return (2)
        }
    }
    
    function killBeam(wall, beam){
        console.log("something died... I hope")
        beam.kill()
    }
    
    
    
    function airLineOfSight (player, enemy, enemyCords, enemySight, enemySpeed){
        playersXCords = player.body.x
        playersYCords = player.body.y
        enemyXCords = enemy.body.x
        enemyYCords = enemy.body.y
        xDistanceAbs = Math.abs(enemyXCords - playersXCords)
        yDistanceAbs = Math.abs(enemyYCords - playersYCords)
        xDistance = enemyXCords - playersXCords
        yDistance = enemyYCords - playersYCords
        if (xDistanceAbs <= enemySight[0] && yDistanceAbs <= enemySight[0]){
            
            
            if (xDistance <= 0 && yDistance <= 0){
                enemy.anchor.setTo(.5,.5);
                enemy.scale.x =-1;
                enemy.body.velocity.x = +enemySpeed[0]
                enemy.body.velocity.y = +enemySpeed[1]
            }
            else if (xDistance > 0 && yDistance > 0){
                enemy.anchor.setTo(.5,.5);
                enemy.scale.x =1;
                enemy.body.velocity.x = -enemySpeed[0]
                enemy.body.velocity.y = -enemySpeed[1]
            }
            else if (xDistance <= 0 && yDistance > 0){
                enemy.anchor.setTo(.5,.5);
                enemy.scale.x =-1;
                enemy.body.velocity.x = +enemySpeed[0]
                enemy.body.velocity.y = -enemySpeed[1]
            }
            else if (xDistance > 0 && yDistance <= 0){
                enemy.body.velocity.x = -enemySpeed[0]
                enemy.body.velocity.y = +enemySpeed[1]
            }
        }
        else if (enemyXCords == enemyCords[0] && enemyYCords == enemyCords[1]){
            enemy.anchor.setTo(.5,.5);
            enemy.scale.x =1;
            enemy.body.velocity.x = 0
            enemy.body.velocity.y = 0    
        }
        else {
            if (enemyXCords >= enemyCords[0]){
                enemy.body.velocity.x = -enemySpeed[0]
            }
            else {
                enemy.body.velocity.x = +enemySpeed[0]
            }
            if (enemyYCords >= enemyCords[1]){
                enemy.body.velocity.y = -enemySpeed[1]
            }
            else {
                enemy.body.velocity.y = +enemySpeed[1]
            }
            
        }
                 
        
        
    }
    


    function getItem(player, items){
        items.kill();
        score += 1;
        scoreText.text = "Score: " + score;
        console.log(score)
        collectSound.play();
    }
    function groundMovement (enemy, counter, xCords, xDist, speed){
    
        enemyPosition = enemy.body.x
        farLeft = xCords - xDist
        farRight = xCords + xDist
        console.log (enemyPosition)
        if (counter == 0) {
            enemy.body.velocity.x = -speed
            if (enemyPosition <= farLeft) {
            
                counter += 1
            }
        
        }
        else if (counter == 1) {
            enemy.body.velocity.x = +speed
            if (enemyPosition >= farRight){
            
                counter -= 1
            }
        
        }
        return counter

    }
    
    function Phase(startPhase){
        console.log(startPhase)
    }
    
    function getRandomInt(max) {
        return Math.floor(Math.random() * max);
    }
    
    function hitboxCreate(){
        console.log("create later")
    }
    
    
    function whatAnimate (movement, action, enemy){
        
        
    
    
        if (movement == 1){
            
            boss.scale.x =-4.6;
            if (action == "idle" || action == "attack1" || action == "attack2" || action == "damage" || action == "death"){
            
                enemy.animations.play(action)
                enemy.body.velocity.x = 0
            }
            
            
            
            
        }
        if (movement == 2){
            
            boss.scale.x =-4.6;
            if (action == "idle" || action == "attack1" || action == "attack2" || action == "damage" || action == "death"){
            
            
                enemy.animations.play(action)
                enemy.body.velocity.x = 0
            }
            
            
            
        }

        
        
        
    }
    
    if (score == 1) {
        game.state.start('winState');
    }
    
}
}