var level2 ={

    

preload:function() {

    game.load.image('ground', 'assets/snowy.png');
    game.load.image('platform1', 'assets/snowyPlatform.png');
    game.load.image('bg', 'assets/snowyBG.png');
    game.load.image('crystal','assets/19.png');
    game.load.image('spike', 'assets/small_metal_spike.png');
    
    game.load.spritesheet('spiritEnemy', 'assets/Vengeful Spirit Sprite Sheet.png', 64, 64);
    game.load.spritesheet('mushroom', 'assets/mushroom.png', 32, 32)
    game.load.spritesheet('player', 'assets/Warrior_Sheet-effect.png', 69, 44);
    game.load.spritesheet('projectile', 'assets/Projectile 2.png',32,32);
    
    game.load.audio('jump', 'assets/Jump 1.wav');
    game.load.audio('hit', 'assets/Hit damage 1.wav');
    game.load.audio('collect', 'assets/Fruit collect 1.wav');
        
    var fireButton; 
    var bullet;
    var playerdirection;
	var projectiles;
    var isDead; 
    var player;
    var platforms;
    var cursors;
    var items;
    var score;
    var scoreText;
    var canDouble=1;
    var enterKey = game.input.keyboard.addKey(Phaser.Keyboard.ENTER);
    var spiritEnemy;
    var mushroomEnemy
    var mushroomCounter;
    var playerVuln;
    var enemyVuln;
    var notAttacking;
    var playerHealth;
    var lastX;
    var lastY;
},
    
create: function(){
       
    //adjust level to however big u want it to be
    //Camera code on line 72
    game.world.setBounds(0, 0, 2000, 700);

    score=0;

    this.keyboard = game.input.keyboard;

    game.add.sprite(0, 0, 'bg')
    platforms = game.add.group();
    platforms.enableBody = true;
    var ground = platforms.create(0, game.world.height - 64, 'ground');
    ground.scale.setTo(2, 2);
    ground.body.immovable = true;
    var ledge = platforms.create(1000, 250, 'platform1');
    ledge.body.immovable = true;
/*    ledge = platforms.create(400, 420, 'platform2');
    ledge.body.immovable = true;*/
    ledge = platforms.create(10, 350, 'platform1');
    ledge.body.immovable = true;
/*    ledge = platforms.create(1400, 150, 'platform2');
    ledge.body.immovable = true;*/
    ledge = platforms.create(1600, 450, 'platform1');
    ledge.body.immovable = true;
    
    items=game.add.group();
    items.enableBody = true;
    for (var i = 0;i<6 ;i++){
        var item= items.create(game.world.randomX, game.world.randomY*0.7, 'crystal')
        item.body.gravity.y=300;
        item.body.bounce.y=0.3 + Math.random()*0.2;
        item++;
    }
    
    spikes = game.add.group();
    spikes.enableBody = true;
    var spike = spikes.create(200, 300, 'spike');
    spike.body.immoveable = true;
    spike = spikes.create(340,300,'spike');
    spike.body.immoveable = true;
    spike = spikes.create(480,300,'spike');
    spike.body.immoveable = true;
    
    spike = spikes.create(1000,200, 'spike');
    spike.body.immoveable = true;
    spike = spikes.create(1140,200,'spike');
    spike.body.immoveable = true;
    spike = spikes.create(1280,200,'spike');
    spike.body.immoveable = true;
    
    spike = spikes.create(1400,580,'spike');
    spike.body.immoveable = true;
    spike = spikes.create(1540,580,'spike');
    spike.body.immoveable = true;
    spike = spikes.create(1680,580,'spike');
    spike.body.immoveable = true;

    player = game.add.sprite(5, game.world.height - 700, 'player');
    camera = game.camera.follow(player, Phaser.Camera.FOLLOW_PLATFORMER);
    player.scale.setTo(1.5, 1.5);
    
    //player.anchor.setTo(.5,.5);
    
    player.health=5;
    playerVuln=true;
    
    game.physics.arcade.enable(player);
    
    player.body.gravity.y = 300;
    player.body.setSize(18,33,18,10);
    
    player.body.collideWorldBounds = true;
    
    player.animations.add('perish',[26,27,28,29,30,31,32,33,34,35,36],10,false);
    player.animations.add('walk', [6,7,8,9,10,11,12,13], 20, true);
    player.animations.add('hurt',[37],10,false);
    player.animations.add('idle', [0,1,2,3,4,5], 10, true);
    player.animations.add('doublejump',[41, 42, 43, 44, 45],10,true);
    player.animations.add('descending',[46,47,48],10,true);
    player.animations.add('attack',[16,17,18,19,20],20,false);


    spiritEnemy = game.add.sprite(400, game.world.height - 500, 'spiritEnemy')
    spiritEnemy.health=3;
    game.physics.arcade.enable(spiritEnemy);
    spiritEnemy.body.collideWorldBounds = true;
    spiritEnemy.animations.add('idle', [0, 1, 2, 3, 4, 5], 10, true);
    
    spiritEnemy1 = game.add.sprite(1200, game.world.height - 800, 'spiritEnemy')
    spiritEnemy1.health=3;
    game.physics.arcade.enable(spiritEnemy1);
    spiritEnemy1.body.collideWorldBounds = true;
    spiritEnemy1.animations.add('idle', [0, 1, 2, 3, 4, 5], 10, true)

    
    mushroomCounter = 0
    mushroomEnemy = game.add.sprite(600, game.world.height - 100, 'mushroom')
    mushroomEnemy.health=2;
    game.physics.arcade.enable(mushroomEnemy);
    mushroomEnemy.body.gravity.y = 300;
    mushroomEnemy.body.collideWorldBounds = true;
    mushroomEnemy.animations.add('left', [19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34], 20, true);
    mushroomEnemy.animations.add('right', [19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34], 20, true);
    mushroomEnemy.animations.add('idle', [5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 18], 20, true);


    cursors = game.input.keyboard.createCursorKeys();
    projectiles=game.add.group();
    projectiles.enableBody=true;
    bullet=projectiles.create(0,0,'projectile');
    bullet.kill();
    bullet.animations.add('fired',[0,1,2,3,4],10,false);
    bullet.animations.add('moving',[5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20],10,true);
    
    fireButton=game.input.keyboard.addKey(Phaser.KeyCode.SPACEBAR);

    scoreText = game.add.text(16, 16, 'score: '+ score, { fontSize: '32px', fill: '#000' });
    cursors = game.input.keyboard.createCursorKeys();
    
    jumpSound = game.add.audio('jump');
    hitSound = game.add.audio('hit');
    collectSound = game.add.audio('collect');

    playerdirection="right";
    enemyVuln=true;
    notAttacking=true;
    isDead=false;
    
    playerHealth = game.add.text(player.x, player.y-8, 'HP: <'+player.health +'>' ,{ fontSize: '16px', fill: '#000' });
       
},


update: function(){

    
    spiritEnemy.animations.play('idle');
    spiritEnemy1.animations.play('idle');
    mushroomEnemy.animations.play('idle');   
    
    
    airLineOfSight(player, spiritEnemy, [100, 300], [100, 200], [50,50]);
    airLineOfSight(player, spiritEnemy1, [1200, 800], [150, 100], [50,50]);

    game.physics.arcade.collide(player, platforms, platformCollide);
    game.physics.arcade.collide(spiritEnemy, platforms);
    game.physics.arcade.collide(spiritEnemy1, platforms);
    game.physics.arcade.collide(items,platforms);
    game.physics.arcade.overlap(player,items,getItem,null,this);
    game.physics.arcade.overlap(player, spiritEnemy, enemyInteraction, null, this);
    game.physics.arcade.overlap(bullet,spiritEnemy,weaponInteraction,null,this);
    game.physics.arcade.overlap(player, spiritEnemy1, enemyInteraction, null, this);
    game.physics.arcade.overlap(bullet,spiritEnemy1,weaponInteraction,null,this);
    game.physics.arcade.overlap(bullet,mushroomEnemy,weaponInteraction,null,this);
    game.physics.arcade.collide(mushroomEnemy, platforms);
    game.physics.arcade.overlap(player, mushroomEnemy, enemyInteraction, null, this);
    
    game.physics.arcade.overlap(player, spikes, spikeCollide, null, this);
    
    game.physics.arcade.collide(player, platforms,platformCollide);
    game.physics.arcade.collide(spiritEnemy, platforms);
    game.physics.arcade.collide(spiritEnemy1, platforms);
    game.physics.arcade.collide(items,platforms);
    game.physics.arcade.overlap(player,items,getItem,null,this);
    game.physics.arcade.collide(player, spiritEnemy, enemyInteraction, null, this);
    game.physics.arcade.collide(bullet,spiritEnemy,weaponInteraction,null,this);
    game.physics.arcade.collide(player, spiritEnemy1, enemyInteraction, null, this);
    game.physics.arcade.collide(bullet,spiritEnemy1,weaponInteraction,null,this);
    game.physics.arcade.collide(bullet,mushroomEnemy,weaponInteraction,null,this);
    game.physics.arcade.collide(mushroomEnemy, platforms);
    game.physics.arcade.collide(player, mushroomEnemy, enemyInteraction, null, this);
    game.physics.arcade.collide(items, spikeCollide, null, this);

    
    //enemy, counter, xCords, xDist, yDist, speed
    mushroomCounter = groundMovement(mushroomEnemy, mushroomCounter, 600, 100, 75);
    
    playerHealth.x=player.x-40;
    playerHealth.y=player.y-50;
    playerHealth.text='HP: <'+player.health+'>';


    if(!cursors.left.isDown && !cursors.right.isDown){
        player.body.velocity.x=0;
    }

    if (cursors.left.isDown)
    {   playerdirection= "left";
        player.body.velocity.x = -150;
        player.anchor.setTo(.5,.5);
        player.scale.x =-1.5;
        if(player.body.velocity.y==0){
            player.animations.play('walk');
        }
        
    }

    else if (cursors.right.isDown)
    {   playerdirection= "right";
     player.body.velocity.x = 150;
     player.anchor.setTo(.5,.5);
     player.scale.x =1.5;
     if(player.body.velocity.y==0){
        player.animations.play('walk');
     }
     
    }

    else if( player.body.velocity.x==0 && player.body.velocity.y==0)
    {
        //player.animations.stop();
        player.animations.play('idle');
    }
    
    
    //cursors.down.onDown.addOnce(dash,this);
    //function dash(){
        
        //player.body.velocity.y=0;
        
            //game.time.events.add(00, (function() {
/*                playerVuln = false;
                if(playerdirection=="right"){
                    player.body.velocity.setTo(10000,0);
                    player.animations.play('ascending');

                }
                else{
                player.body.velocity.setTo(-10000,0);
                player.animations.play('ascending');
                }
            }), this); 
        
            playerVuln=true;*/
        
        //if(cursors.right.isDown){
            //player.body.velocity.x=350;
//            player.anchor.setTo(.5,.5);
//            player.scale.x =1;
            
            //player.animations.play('ascending');

        //}else if(cursors.left.isDown){
//            player.anchor.setTo(.5,.5);
//            player.scale.x =-1;
            //player.body.velocity.x=-350;
            
           // player.animations.play('ascending');
       // }
    //}
    
    cursors.up.onDown.add(jumpCheck);
    
    fireButton.onDown.addOnce(shoot,this);
    
    function shoot() {
        notAttacking=false;
        player.animations.play('attack');
        	var bulletDirection=playerdirection;
            
        	if(bulletDirection=="right"){
            		bullet=projectiles.create(player.x,player.y-25,'projectile');
            		bullet.lifespan=700;
            		bullet.scale.setTo(2,2);
            		
                    
            		bullet.animations.play('moving');
            		bullet.body.velocity.x=375
        	}else if( bulletDirection="left"){
            		bullet=projectiles.create(player.x,player.y-25,'projectile');
            		bullet.lifespan=700;
            		bullet.scale.setTo(-2,2);
            		
            		bullet.animations.play('moving');
            		bullet.body.velocity.x=-375;
            		bullet.scale.x= -2;
        	}

        game.time.events.add(200, (function() {    
            notAttacking=true;
        }), this); 

        
    }
    
    function jumpCheck() {
        if((jumpCount < 1) && (player.body.touching.down)){
            jump();
           jumpHeight=0.66;
            jumpSound.play();
            
        }
        if((jumpCount < 2) && (!player.body.touching.down)){
            jump();
            jumpSound.play()
  
        }

    }

    function jump(){
       
        jumpCount ++;
        player.body.velocity.y = -350*jumpHeight;
        player.animations.play('doublejump');
        jumpSound.play();
    }

    function platformCollide(){
       if(player.body.touching.down){
            lastX=player.x;
            lastY=player.y;
            jumpCount = 0;
            jumpHeight=1;
        }
    }
    
    function spikeCollide(){
        if(playerVuln){
            console.log("spike damage")
            console.log(player.health)
            playerVuln=false;
            if(player.body.touching.down){
                player.x=lastX;
                player.y=lastY;
                player.damage(1);
                if(player.health==0){
                    game.state.start('deathState')
                }
                game.time.events.add(400, (function() {
                    playerVuln = true;
                }), this); 
            }
        }
    }
    
    function enemyInteraction (player, enemy) {
        if(player.body.touching.down && enemy.body.touching.up ){
            if(enemyVuln){
                if(enemy.health==1){
                    score += 1;
                    scoreText.text = "Score: " + score;
                }
                //console.log("detect goomba");
                enemy.damage(1);
                hitSound.play();
                enemyVuln=false;
                game.time.events.add(400, (function() {
                    enemyVuln = true;
                  //  console.log("enemy vulnerable");
                }), this); 
            }
            enemy.body.velocity.setTo(-200,400);
            jumpCount=1;
            jumpHeight=0.33;
            jump();
            jumpCount=1;
            jumpHeight=0.66;
            
            
        }else {if(playerVuln){
           // console.log("detect damage");
           if(player.health==1){
            
            isDead=true;
            player.animations.play('perish'); 
            game.time.events.add(2000,function(){
                console.log('trying to animate')
                
                game.time.events.add(1000,function(){
                    console.log('murder committed')
                    game.state.start('gameState');});
                
            });
            
           }
           
           player.damage(1);
           playerVuln=false;
           //console.log("player invulnerable");
           player.animations.play('hurt');
           game.time.events.add(700, (function() {
                playerVuln = true;
                //console.log("player vulnerable");
           }), this); 
           
           
           
        }
    }
    }

    function weaponInteraction(bullet,enemy){
        if(enemy.health==1){
            score += 1;
            scoreText.text = "Score: " + score;
        }
        enemy.damage(1);
        bullet.kill();
        
    }
    function airLineOfSight (player, enemy, enemyCords, enemySight, enemySpeed){
        playersXCords = player.body.x
        playersYCords = player.body.y
        enemyXCords = enemy.body.x
        enemyYCords = enemy.body.y
        xDistanceAbs = Math.abs(enemyXCords - playersXCords)
        yDistanceAbs = Math.abs(enemyYCords - playersYCords)
        xDistance = enemyXCords - playersXCords
        yDistance = enemyYCords - playersYCords
        if (xDistanceAbs <= enemySight[0] && yDistanceAbs <= enemySight[0]){
            
            
            if (xDistance <= 0 && yDistance <= 0){
                enemy.anchor.setTo(.5,.5);
                enemy.scale.x =-1;
                enemy.body.velocity.x = +enemySpeed[0]
                enemy.body.velocity.y = +enemySpeed[1]
            }
            else if (xDistance > 0 && yDistance > 0){
                enemy.anchor.setTo(.5,.5);
                enemy.scale.x =1;
                enemy.body.velocity.x = -enemySpeed[0]
                enemy.body.velocity.y = -enemySpeed[1]
            }
            else if (xDistance <= 0 && yDistance > 0){
                enemy.anchor.setTo(.5,.5);
                enemy.scale.x =-1;
                enemy.body.velocity.x = +enemySpeed[0]
                enemy.body.velocity.y = -enemySpeed[1]
            }
            else if (xDistance > 0 && yDistance <= 0){
                enemy.body.velocity.x = -enemySpeed[0]
                enemy.body.velocity.y = +enemySpeed[1]
            }
        }
        else if (enemyXCords == enemyCords[0] && enemyYCords == enemyCords[1]){
            enemy.anchor.setTo(.5,.5);
            enemy.scale.x =1;
            enemy.body.velocity.x = 0
            enemy.body.velocity.y = 0    
        }
        else {
            if (enemyXCords >= enemyCords[0]){
                enemy.body.velocity.x = -enemySpeed[0]
            }
            else {
                enemy.body.velocity.x = +enemySpeed[0]
            }
            if (enemyYCords >= enemyCords[1]){
                enemy.body.velocity.y = -enemySpeed[1]
            }
            else {
                enemy.body.velocity.y = +enemySpeed[1]
            }
            
        }
                 
        
        
    }
    


    function getItem(player, items){
        items.kill();
        score += 1;
        scoreText.text = "Score: " + score;
        
        collectSound.play();
    }
    function groundMovement (enemy, counter, xCords, xDist, speed){
    
        enemyPosition = enemy.body.x
        farLeft = xCords - xDist
        farRight = xCords + xDist
        
        if (counter == 0) {
            enemy.body.velocity.x = -speed
            if (enemyPosition <= farLeft) {
            
                counter += 1
            }
        
        }
        else if (counter == 1) {
            enemy.body.velocity.x = +speed
            if (enemyPosition >= farRight){
            
                counter -= 1
            }
        
        }
        return counter

    }
    if (score >= 4) {
        game.state.start('getReadyState3');
    }
}
    
}
