var winState = {
    preload: function(){
        game.load.image('winTXT', 'assets/winTXT.png');
        game.load.image('bg', 'assets/TutorialBG.png');
        game.load.image('cont', 'assets/cont.png');
    },
    
    create: function(){
        game.add.sprite(0,0,'bg');
        game.add.sprite(200, 300, 'winTXT');
        game.add.sprite(900, 550, 'cont');
        
        var enterKey = game.input.keyboard.addKey(Phaser.Keyboard.ENTER);
        
        enterKey.onDown.addOnce(this.play, this);
    },
    
    play: function(){
        game.state.start('overworldstate');
    }
}