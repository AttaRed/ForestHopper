var level2Boss ={

    

preload:function() {

    game.load.image('ground', 'assets/graveyardground.png');
    game.load.image('platform1', 'assets/graveyardplatform1.png');
    //game.load.image('platform2', 'assets/graveyardplatform2.png');
    game.load.image('bg', 'assets/graveyard.png');
    //game.load.spritesheet('player', 'assets/spritesheet.png', 96, 84);
    //game.load.spritesheet('player', 'assets/bunnywork.png', 46, 90, 59);
    
    game.load.spritesheet('player', 'assets/Warrior_Sheet-Effect.png', 69, 44);
    game.load.image('bag','assets/bag.png');
    //game.load.spritesheet('bat', 'assets/bat.png', 46, 30);
    //game.load.spritesheet('mushroom', 'assets/mushroom.png', 32, 32)
    game.load.spritesheet('projectile', 'assets/Projectile 2.png',32,32)
    
    game.load.spritesheet('gorilla', 'assets/Giant Gorilla Sprite Sheet.png', 64, 64)
    
    
    
    game.load.image('48-1','assets/gorillaHitboxes/48(1).png');
    game.load.image('48-2','assets/gorillaHitboxes/48(2).png');
    game.load.image('49-1','assets/gorillaHitboxes/49(1).png');
    game.load.image('49-2','assets/gorillaHitboxes/49(2).png');
    game.load.image('50-1','assets/gorillaHitboxes/50(1).png');
    game.load.image('50-2','assets/gorillaHitboxes/50(2).png');
    game.load.image('51','assets/gorillaHitboxes/51.png');
    game.load.image('52','assets/gorillaHitboxes/52.png');
    game.load.image('53','assets/gorillaHitboxes/53.png');
    game.load.image('54','assets/gorillaHitboxes/54.png');
    game.load.image('61','assets/gorillaHitboxes/61.png');
    game.load.image('62','assets/gorillaHitboxes/62.png');
    game.load.image('63-1','assets/gorillaHitboxes/63(1).png');
    game.load.image('63-2','assets/gorillaHitboxes/63(2).png');
    game.load.image('64','assets/gorillaHitboxes/64.png');
    game.load.image('65','assets/gorillaHitboxes/65.png');
    game.load.image('66','assets/gorillaHitboxes/66.png');
    game.load.image('67','assets/gorillaHitboxes/67.png');
    game.load.image('68','assets/gorillaHitboxes/68.png');
    
    
    game.load.audio('jump', 'assets/Jump 1.wav');
    game.load.audio('hit', 'assets/Hit damage 1.wav');
    game.load.audio('collect', 'assets/Fruit collect 1.wav');
        
    var player;
    var platforms;
    var cursors;
    var items;
    var score;
    var scoreText;
    var canDouble=1;
    var enterKey = game.input.keyboard.addKey(Phaser.Keyboard.ENTER);
    //var batEnemy;
    //var mushroomEnemy
    var boss
    var mushroomCounter;
    var projectiles;
    var bullet;
    var floor;
    
    var movement;
    var action;
    var actionList;
    
    var playerVuln;
    var enemyVuln;
    
    var playerHealth;
},
    
create: function(){
    
    game.world.setBounds(0, 0, 1058, 600);


    score=0;

    this.keyboard = game.input.keyboard;

    background1 = game.add.sprite(0, 0, 'bg')
//    background2 = game.add.sprite(0, 600, 'bg')
//    background3 = game.add.sprite(1058, 0, 'bg')
//    background4 = game.add.sprite(1058, 600, 'bg')
    background1.scale.setTo(4,4)
    platforms = game.add.group();
    platforms.enableBody = true;
    var ground = platforms.create(0, 525, 'ground');
    ground.scale.setTo(2, 2);
    ground.body.immovable = true;
    var ledge = platforms.create(2300,800, 'platform1');
    ledge.body.immovable = true;
    //ledge = platforms.create(400, 320, 'platform2');
    //ledge.body.immovable = true;
    //ledge = platforms.create(10, 100, 'platform1');
    //ledge.body.immovable = true;

    
    items=game.add.group();
    items.enableBody = true;
//    for (var i = 0;i<6 ;i++){
//        var item= items.create(game.world.randomX, game.world.randomY*0.7, 'bag')
//        item.body.gravity.y=300;
//        item.body.bounce.y=0.3 + Math.random()*0.2;
//        item++;
//    }

    player = game.add.sprite(96, 400, 'player');
    camera = game.camera.follow(player, Phaser.Camera.FOLLOW_PLATFORMER);

    
    player.scale.setTo(1.5, 1.5);
    player.health=5;
    playerVuln=true;
    
    game.physics.arcade.enable(player);
    
    player.body.gravity.y = 300;
    
    player.body.setSize(18,33,18,10);
    player.body.collideWorldBounds = true;

    player.animations.add('perish',[26,27,28,29,30,31,32,33,34,35,36],10,false);
    player.animations.add('walk', [6,7,8,9,10,11,12,13], 20, true);
    player.animations.add('hurt',[37],10,false);
    player.animations.add('idle', [0,1,2,3,4,5], 10, true);
    player.animations.add('doublejump',[41, 42, 43, 44, 45],10,true);
    player.animations.add('descending',[46,47,48],10,true);
    player.animations.add('attack',[16,17,18,19,20],20,false);
    
    boss = game.add.sprite(400, 200, 'gorilla');
    
    boss.scale.setTo(4.6, 4.6);
    boss.health=20;
    game.physics.arcade.enable(boss);
    boss.body.gravity.y = 300;
    boss.body.collideWorldBounds = true;
    
    boss.anchor.setTo(.5,.5);
    //boss.scale.x =-4.6;
    
    boss.animations.add('all', [0, 1, 2, 3, 12, 13, 14, 15, 16, 17, 24, 25, 26, 36, 37, 38, 39, 40, 41, 26, 25, 24, 48, 49, 50, 51, 52, 53, 54, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 84, 85, 86, 87, 96, 97, 98, 99, 100, 108, 109, 110, 111, 112, 113], 10, true);
    
    boss.animations.add('idle', [0, 1, 2, 3], 10, true);
    
    boss.animations.add('walk', [12, 13, 14, 15, 16, 17], 10, true);
    
    boss.animations.add('getUp', [24, 25, 26], 10, true);
    
    boss.animations.add('angryRun', [36, 37, 38, 39, 40, 41], 10, true);
    
    boss.animations.add('attack1', [48, 49, 50, 51, 52, 53, 54], 10, true);
    
    boss.animations.add('attack2', [60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71], 15, true);
    
    boss.animations.add('taunt', [72, 73, 74, 75], 10, true);
    
    boss.animations.add('damage', [84, 85, 86, 87], 10, true);
    
    boss.animations.add('death', [96, 97, 98, 99, 100], 10, true);
    
    boss.animations.add('test', [4, 54], 1, true);
    
    
    // regularRight set size
    //boss.body.setSize(20, 27, 23, 37);
    
    //Facing left body size
    boss.body.setSize(23, 37, 20, 27);
    
    
    mushroomCounter = 0



    cursors = game.input.keyboard.createCursorKeys();
    projectiles=game.add.group();
    projectiles.enableBody=true;
    bullet=projectiles.create(0,0,'projectile');
    bullet.kill();
    bullet.animations.add('fired',[0,1,2,3,4],10,false);
    bullet.animations.add('moving',[5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20],10,true);
    
    attackBoxes=game.add.group();
    attackBoxes.enableBody=true;
    attackBox=projectiles.create(0,0,'48-1');
    attackBox.kill();
    
    
    fireButton=game.input.keyboard.addKey(Phaser.KeyCode.SPACEBAR);

    scoreText = game.add.text(16, 16, 'score: '+ score, { fontSize: '32px', fill: '#000' });
    cursors = game.input.keyboard.createCursorKeys();
    
    jumpSound = game.add.audio('jump');
    hitSound = game.add.audio('hit');
    collectSound = game.add.audio('collect');

    playerdirection="right";
    enemyVuln=true;
    notAttacking=true;
    isDead=false;
    movement = 1
    cycle = 0
    actionList = ["idle", "walk", "angryRun", "attack1", "attack1", "attack2", "taunt", "angryRun"] 
    //"damage1", "damage2", "death"]
    action = 0
    
    startPhase = 350
    
    ticks = 100
    
    appear = 0
    
    playerHealth = game.add.text(player.x, player.y-8, 'HP: <'+player.health +'>' ,{ fontSize: '16px', fill: '#000' });
    
},


update: function(){
    
    
    hitboxCreate()
    
    movement = enemyDirection(player, boss, movement)
    startPhase++
    if (startPhase == 351){
        whatAnimate(movement, 'taunt', boss)
        startPhase = 0
    }
    if (startPhase == ticks){
        action = getRandomInt(actionList.length)
        console.log(actionList[action])
        whatAnimate(movement, actionList[action], boss)
        
        startPhase = 0
        if (actionList[action] == "idle"){
            ticks = 75
        }
        if (actionList[action] == "taunt"){
            ticks = 50
        }
        if (actionList[action] == "walk"){
            ticks = 100
            
        }
        if (actionList[action] == "angryRun"){
            ticks = 125
            //angryRun
        }
        if (actionList[action] == "attack1"){
            ticks = 50
        }
        if (actionList[action] == "attack2"){
            ticks = 50
        }
        
        
        
    }
    

    if (playerVuln){
        game.physics.arcade.overlap(player,attackBoxes,toKill,null,this);
    }
    
    game.physics.arcade.overlap(bullet,boss,weaponInteraction,null,this);
    game.physics.arcade.collide(boss, platforms);
    game.physics.arcade.overlap(player, boss, enemyInteraction, null, this);

    game.physics.arcade.collide(player, platforms, platformCollide);

    game.physics.arcade.collide(items,platforms);
    game.physics.arcade.overlap(player,items,getItem,null,this);

    playerHealth.x=player.x-40;
    playerHealth.y=player.y-50;
    playerHealth.text='HP: <'+player.health+'>';
    
    if(!cursors.left.isDown && !cursors.right.isDown){
        player.body.velocity.x=0;
    }

    if (cursors.left.isDown)
    {
        playerdirection= "left";
        player.body.velocity.x = -150;
        player.anchor.setTo(.5,.5);
        player.scale.x =-1.5;
        if(player.body.velocity.y==0){
            player.animations.play('walk');
        }
        
    }

    else if (cursors.right.isDown)
    {
        playerdirection= "right";
     player.body.velocity.x = 150;
     player.anchor.setTo(.5,.5);
     player.scale.x =1.5;
     if(player.body.velocity.y==0){
        player.animations.play('walk');
     }
     
    }


    else if( player.body.velocity.x==0 && player.body.velocity.y==0 && notAttacking && !isDead)
    {
        player.animations.play('idle');
    }
    
    
    cursors.down.onDown.addOnce(dash,this);
    function dash(){
        game.time.events.add(01, (function() {
            playerVuln = false;
            if(playerdirection=="right"){
                player.body.velocity.setTo(10000,0);
                player.animations.play('ascending');
                playerVuln=true;

            }
            else{
                
                player.body.velocity.setTo(-10000,0);
                player.animations.play('ascending');
                playerVuln=true;
            }
        }), this); 
    }
    
    
    cursors.up.onDown.add(jumpCheck);
    
    fireButton.onDown.addOnce(shoot,this);
    
    function toKill(){
        //console.log("u were indeed just hit")
        player.damage(1);
        
        playerVuln=false;
        
        //console.log("player invulnerable");
        game.time.events.add(1000, (function() {
            playerVuln = true;
            //console.log("player vulnerable");
        }), this); 
        
           
        if(player.health==0){
            game.state.start('overworldstate');
        }
    }
    
    function shoot() {
        notAttacking=false;
        player.animations.play('attack');
        
            
       
        	var bulletDirection=playerdirection;
            
        	if(bulletDirection=="right"){
            		bullet=projectiles.create(player.x,player.y-25,'projectile');
            		bullet.lifespan=700;
            		bullet.scale.setTo(2,2);
            		
                    
            		bullet.animations.play('moving');
            		bullet.body.velocity.x=375
        	}else if( bulletDirection="left"){
            		bullet=projectiles.create(player.x,player.y-25,'projectile');
            		bullet.lifespan=700;
            		bullet.scale.setTo(-2,2);
            		
            		bullet.animations.play('moving');
            		bullet.body.velocity.x=-375;
            		bullet.scale.x= -2;
        	}

        game.time.events.add(200, (function() {    
            notAttacking=true;
        }), this); 

        
    }

    
    function jumpCheck() {
        if((jumpCount < 1) && (player.body.touching.down)){
            jump();
           jumpHeight=0.66;
            jumpSound.play();
            
        }
        if((jumpCount < 2) && (!player.body.touching.down)){
            jump();
            jumpSound.play()
  
        }

    }

    function jump(){
       
        jumpCount ++;
        player.body.velocity.y = -350*jumpHeight;
        player.animations.play('doublejump');
        jumpSound.play();
    }

    
    
    if (player.body.velocity.y >0){
        player.animations.play('descending');
    }
    var enterKey = game.input.keyboard.addKey(Phaser.Keyboard.ENTER);
    var attacking
        
    function platformCollide(){
    
        if(player.body.touching.down){
            jumpCount = 0;
            jumpHeight=1;
        }
        
    }
    
    
    function enemyInteraction (player, enemy) {
        
        if(player.body.touching.down && enemy.body.touching.up ){
            if(enemyVuln){
                if(enemy.health==1){
                    score += 1;
                    scoreText.text = "Score: " + score;
                }
                //console.log("detect goomba");
                enemy.damage(1);
                hitSound.play();
                enemyVuln=false;
                game.time.events.add(4000, (function() {
                    enemyVuln = true;
                  //  console.log("enemy vulnerable");
                }), this); 
            }
            enemy.body.velocity.setTo(-200,400);
            jumpCount=1;
            jumpHeight=0.33;
            jump();
            jumpCount=1;
            jumpHeight=0.66;
            
            
        }else {if(playerVuln){
           // console.log("detect damage");
           if(player.health==1){
            
            isDead=true;
            player.animations.play('perish'); 
            game.time.events.add(2000,function(){
                console.log('trying to animate')
                
                game.time.events.add(1000,function(){
                    console.log('murder committed')
                    game.state.start('overworldstate');});
                
            });
            
           }
           
           player.damage(1);
           playerVuln=false;
           //console.log("player invulnerable");
           player.animations.play('hurt');
           game.time.events.add(700, (function() {
                playerVuln = true;
                //console.log("player vulnerable");
           }), this); 
           
           
           
        }
    }
    }


    function weaponInteraction(bullet,enemy){
        if(enemy.health==1){
            score += 1;
            scoreText.text = "Score: " + score;
        }
        enemy.damage(1);
        bullet.kill();
        
    }
    function enemyDirection(player, enemy, movement){
        playersXCords = player.body.x
        enemyXCords = enemy.body.x
        //xDistanceAbs = Math.abs(enemyXCords - playersXCords)
        
        if (enemyXCords - playersXCords >= 0){
            return (1)
        }
        else {
            return (2)
        }
    }
    
    
    
    
    function airLineOfSight (player, enemy, enemyCords, enemySight, enemySpeed){
        playersXCords = player.body.x
        playersYCords = player.body.y
        enemyXCords = enemy.body.x
        enemyYCords = enemy.body.y
        xDistanceAbs = Math.abs(enemyXCords - playersXCords)
        yDistanceAbs = Math.abs(enemyYCords - playersYCords)
        xDistance = enemyXCords - playersXCords
        yDistance = enemyYCords - playersYCords
        if (xDistanceAbs <= enemySight[0] && yDistanceAbs <= enemySight[0]){
            
            
            if (xDistance <= 0 && yDistance <= 0){
                enemy.anchor.setTo(.5,.5);
                enemy.scale.x =-1;
                enemy.body.velocity.x = +enemySpeed[0]
                enemy.body.velocity.y = +enemySpeed[1]
            }
            else if (xDistance > 0 && yDistance > 0){
                enemy.anchor.setTo(.5,.5);
                enemy.scale.x =1;
                enemy.body.velocity.x = -enemySpeed[0]
                enemy.body.velocity.y = -enemySpeed[1]
            }
            else if (xDistance <= 0 && yDistance > 0){
                enemy.anchor.setTo(.5,.5);
                enemy.scale.x =-1;
                enemy.body.velocity.x = +enemySpeed[0]
                enemy.body.velocity.y = -enemySpeed[1]
            }
            else if (xDistance > 0 && yDistance <= 0){
                enemy.body.velocity.x = -enemySpeed[0]
                enemy.body.velocity.y = +enemySpeed[1]
            }
        }
        else if (enemyXCords == enemyCords[0] && enemyYCords == enemyCords[1]){
            enemy.anchor.setTo(.5,.5);
            enemy.scale.x =1;
            enemy.body.velocity.x = 0
            enemy.body.velocity.y = 0    
        }
        else {
            if (enemyXCords >= enemyCords[0]){
                enemy.body.velocity.x = -enemySpeed[0]
            }
            else {
                enemy.body.velocity.x = +enemySpeed[0]
            }
            if (enemyYCords >= enemyCords[1]){
                enemy.body.velocity.y = -enemySpeed[1]
            }
            else {
                enemy.body.velocity.y = +enemySpeed[1]
            }
            
        }
                 
        
        
    }
    


    function getItem(player, items){
        items.kill();
        score += 1;
        scoreText.text = "Score: " + score;
        console.log(score)
        collectSound.play();
    }
    function groundMovement (enemy, counter, xCords, xDist, speed){
    
        enemyPosition = enemy.body.x
        farLeft = xCords - xDist
        farRight = xCords + xDist
        console.log (enemyPosition)
        if (counter == 0) {
            enemy.body.velocity.x = -speed
            if (enemyPosition <= farLeft) {
            
                counter += 1
            }
        
        }
        else if (counter == 1) {
            enemy.body.velocity.x = +speed
            if (enemyPosition >= farRight){
            
                counter -= 1
            }
        
        }
        return counter

    }
    
    function Phase(startPhase){
        console.log(startPhase)
    }
    
    function getRandomInt(max) {
        return Math.floor(Math.random() * max);
    }
    
    function hitboxCreate(){
        
        if (movement == 1){
            if (boss.frame == 48){
                box=attackBoxes.create(boss.x+8, boss.y+28,'48-1')
                box1=attackBoxes.create(boss.x-67, boss.y+28,'48-2')
                box.lifespan=1;
                box1.lifespan=1;
            }
    
            if (boss.frame == 49){
        
                box=attackBoxes.create(boss.x+20, boss.y+36,'49-1')
                box1=attackBoxes.create(boss.x-67, boss.y+36,'49-2')
                box.lifespan=1;
                box1.lifespan=1;
        
    
            }
    
            if (boss.frame == 50){
        
                box=attackBoxes.create(boss.x-26, boss.y+47,'50-1')
                box1=attackBoxes.create(boss.x-84, boss.y+25,'50-2')
                box.lifespan=1;
                box1.lifespan=1;
        
    
            }
    
            if (boss.frame == 51){
        
                box=attackBoxes.create(boss.x-100, boss.y-30,'51')
                box.lifespan=1;
        
        
    
            }
    
            if (boss.frame == 52){
        
                box=attackBoxes.create(boss.x-62, boss.y-94,'52')
                box.lifespan=1;
        
        
    
            }
    
            if (boss.frame == 53 ){
        
                box=attackBoxes.create(boss.x-100, boss.y+101,'53')
                box.lifespan=1;
        
        
    
            }
    
            if (boss.frame == 54 ){
        
                box=attackBoxes.create(boss.x-100, boss.y+101,'54')
                box.lifespan=1;
            }
    
            if (boss.frame == 61 ){
            
                box=attackBoxes.create(boss.x+7, boss.y+20,'61')
                box.lifespan=1;
            }
    
            if (boss.frame == 62 ){
        
                box=attackBoxes.create(boss.x+22, boss.y-20,'62')
                box.lifespan=1;
            }
    
            if (boss.frame == 63 ){
            
                box=attackBoxes.create(boss.x+27, boss.y-40,'63-1')
                box1=attackBoxes.create(boss.x-100, boss.y-40,'63-2')
                box.lifespan=1;
                box1.lifespan=1;
            }
    
            if (boss.frame == 64 ){
        
                box=attackBoxes.create(boss.x-100, boss.y-115,'64')
                box.lifespan=1;
            }
    
            if (boss.frame == 65 ){
        
                box=attackBoxes.create(boss.x-50, boss.y-15,'65')
                box.lifespan=1;
            }
    
            if (boss.frame == 66 ){
        
                box=attackBoxes.create(boss.x-65, boss.y+0,'66')
                box.lifespan=1;
            }
    
            if (boss.frame == 67 ){
        
                box=attackBoxes.create(boss.x-135, boss.y-56,'67')
                box.lifespan=1;
            }
    
            if (boss.frame == 68 ){
        
                box=attackBoxes.create(boss.x-140, boss.y+98,'68')
                box.lifespan=1;
            }
            
        }
        
        if (movement == 2){
            if (boss.frame == 48){

                box=attackBoxes.create(boss.x-60, boss.y+28,'48-1')
                box1=attackBoxes.create(boss.x+10, boss.y+28,'48-2')
                box.lifespan=1;
                box1.lifespan=1;

    
            }
        
            if (boss.frame == 49){
        
                box=attackBoxes.create(boss.x-55, boss.y+36,'49-1')
                box1=attackBoxes.create(boss.x+20, boss.y+36,'49-2')
                box.lifespan=1;
                box1.lifespan=1;
        
    
            }
    
            if (boss.frame == 50){
        
                box=attackBoxes.create(boss.x-60, boss.y+47,'50-1')
                box1=attackBoxes.create(boss.x+26, boss.y+25,'50-2')
                box.lifespan=1;
                box1.lifespan=1;
        
    
            }
    
            if (boss.frame == 51){
        
                box=attackBoxes.create(boss.x-70, boss.y-30,'51')
                box.lifespan=1;
        
        
    
            }
    
            if (boss.frame == 52){
        
                box=attackBoxes.create(boss.x-85, boss.y-94,'52')
                box.lifespan=1;
        
        
    
            }
    
            if (boss.frame == 53 ){
        
                box=attackBoxes.create(boss.x-10, boss.y+101,'53')
                box.lifespan=1;
        
        
    
            }
    
            if (boss.frame == 54 ){
            
                box=attackBoxes.create(boss.x-8, boss.y+101,'54')
                box.lifespan=1;
            }
        
            if (boss.frame == 61 ){
        
                box=attackBoxes.create(boss.x-115, boss.y+20,'61')
                box.lifespan=1;
            }
    
            if (boss.frame == 62 ){
         
                box=attackBoxes.create(boss.x-130, boss.y-20,'62')
                box.lifespan=1;
            }
    
            if (boss.frame == 63 ){
        
                box=attackBoxes.create(boss.x-130, boss.y-40,'63-1')
                box1=attackBoxes.create(boss.x+38, boss.y-40,'63-2')
                box.lifespan=1;
                box1.lifespan=1;
            }
    
            if (boss.frame == 64 ){
        
                box=attackBoxes.create(boss.x-125, boss.y-115,'64')
                box.lifespan=1;
            }
        
            if (boss.frame == 65 ){
        
                box=attackBoxes.create(boss.x-145, boss.y-15,'65')
                box.lifespan=1;
            }
    
            if (boss.frame == 66 ){
        
                box=attackBoxes.create(boss.x-140, boss.y+0,'66')
                box.lifespan=1;
            }
    
            if (boss.frame == 67 ){
        
                box=attackBoxes.create(boss.x-20, boss.y-56,'67')
                box.lifespan=1;
            }
    
            if (boss.frame == 68 ){
        
                box=attackBoxes.create(boss.x+45, boss.y+98,'68')
                box.lifespan=1;
            }
        }
        
    
    
        
    }
    
    
    function whatAnimate (movement, action, enemy){
        
        
        if (movement == 1){
            
            boss.scale.x =-4.6;
            if (action == "idle" || action == "attack1" || action == "taunt" || action == "damage" || action == "death"){
            
                enemy.animations.play(action)
                enemy.body.velocity.x = 0
            }
            
            if (action == "walk") {
            
                enemy.animations.play(action)
                enemy.body.velocity.x = -100
            }
            if (action == "angryRun") {
                
                
                enemy.animations.play(action)
                
                
                enemy.body.velocity.x = -200
                
            
                
                
            }
            if (action == "attack2") {
            
                enemy.animations.play(action)
                enemy.body.velocity.x = -250
            }
            
            
        }
        if (movement == 2){
            
            boss.scale.x =4.6;
            if (action == "idle" || action == "attack1" || action == "taunt" || action == "damage" || action == "death"){
            
            
                enemy.animations.play(action)
                enemy.body.velocity.x = 0
            }
            
            if (action == "walk") {
            
                enemy.animations.play(action)
                enemy.body.velocity.x = +100
            }
            if (action == "angryRun") {
            
                enemy.animations.play(action)
                enemy.animations.play(action)
                if (enemy.frame == 24 || enemy.frame == 25 || enemy.frame == 26){
        
                    enemy.body.velocity.x = 0
                }
                
                enemy.body.velocity.x = +200
                
                
            }
            
            if (action == "attack2") {
            
                enemy.animations.play(action)
                enemy.body.velocity.x = +250
            }
            
            
        }
        
        
        
//        if (action == "idle" || action == "walk" || action == "attack1" || action == "taunt" || action == "damage", || action == "death"){
//            
//            
//            enemy.animations.play(action)
//            enemy.body.velocity.x = 0
//        }
//            
//        if (animate == "walk") {
//            
//            enemy.animations.play(action)
//            enemy.body.velocity.x = -50
//        }
//        if (animate == "angryRun") {
//            
//            enemy.animations.play(action)
//            enemy.body.velocity.x = -100
//        }
//        if (animate == "attack1") {
//            
//            enemy.animations.play(animate)
//            enemy.body.velocity.x = -100
//        }
        
        
    
        
        
        
        
    }
    
    if (score == 1) {
        game.state.start('winState');
    }
    
}
}